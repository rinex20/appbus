<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();
/* mysql_query("SET NAMES 'utf8'");
mysql_query("SET CHARACTER_SET_CLIENT=utf8");
mysql_query("SET CHARACTER_SET_RESULTS=utf8");  */
$conn->query('SET NAMES utf8'); 
$conn->query("SET CHARACTER_SET_CLIENT=utf8");
$conn->query("SET CHARACTER_SET_RESULTS=utf8");

$jsoncallback = C_GET("jsoncallback");
$type = C_GET("type");
header('Content-Type: text/html; charset=utf-8');
$g_apps = array();
$response = array();
$s1= array();
$s2= array();
$s3= array();
$arr2 = array();
$devicetype = C_REQUEST('devicetype');

function getPackageNameIdx($packagename, $list){
    $idx = -1;
    foreach ($list as $i => $value) {
        if ($value == $packagename){
            $idx = $i;
            break;
        }
    }
    return $idx;
}
//$sql = "select appid,sets,status,starts,icon from shortcut,apps_setstatus,c_apps where apps_setstatus.sets = '$devicetype' and shortcut.setid = apps_setstatus.setid and shortcut.appid = c_apps.id and c_apps.isoffshelf = false";
$sql = "select appid,sets,status,starts,icon from {$dbPrefix}shortcut,{$dbPrefix}setstatus,{$dbPrefix}apps where {$dbPrefix}setstatus.sets = '$devicetype' and {$dbPrefix}shortcut.setid = {$dbPrefix}setstatus.setid and {$dbPrefix}shortcut.appid = {$dbPrefix}apps.id and {$dbPrefix}apps.isoffshelf = false and {$dbPrefix}apps.id = (select max(id) from {$dbPrefix}apps)";
$result = $conn->query($sql);
$shortcutType = array();
if($result){
	while($rows = $result->fetch()){
		$g_apps[] = $rows;
	}
}

/* while ($rows = mysql_fetch_array($result))
{
  $g_apps[] = $rows;
} */
if ($result){    
    if ($g_apps){
	foreach ($g_apps as $key => $cuts){
		unset($_t);
	    $_t["appid"] = $cuts["appid"];
	    $_t["icon"] ="<img src='upload/".$_t["appid"]."/".$cuts["icon"]."'>";
		$_t["sets"] = $cuts["sets"];
		$_t["starts"] = $cuts["starts"];
		$s1[]=$_t;
	}
		$is_col =  false;
		foreach($s1 as $key=>$val1)
		{
			$is_col =  false;
			foreach($arr2 as $key2=>$val2)
			{
				  if($val2["sets"] == $val1["sets"])
				  {
					   $is_col = true;
					   $arr2[$key2]["appid"] = $val1["appid"].",".$val2["appid"];
					   $arr2[$key2]["icon"] = $val1["icon"].$val2["icon"];
						
				  }
			}     
			if(!$is_col)
			{
			if(!in_array($val1,$arr2))
			{
			   array_push($arr2,$val1);
			}
			}
		}
		$response = $arr2;
    }
    else{
        $response["result"] = 2;
    }
}
else{
    $response["result"] = 1;
}

if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}


?>