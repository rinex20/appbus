<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();

include("config/fg_config.php");

session_start();

$jsoncallback = C_GET("jsoncallback");

header('Content-Type: text/html; charset=utf-8');

$appid = C_REQUEST('id');
$type = C_REQUEST('type');
$value = C_REQUEST('value');
$arr = array();
$arrstr = "";
if($appid != "" && $type != "" && $value != ""){
	$sql = "select * from {$dbPrefix}shortcut";
	$result = $conn->query($sql);
	$sqlselect = "select * from {$dbPrefix}shortcut where appid = '$appid'";
	$results = $conn->query($sqlselect);
	if($results){
		while($rows = $results->fetch(PDO::FETCH_ASSOC)){
			$g_apps = $rows;
		}
		
		if(count($value)>1){
			foreach ($value as $k => $v){
				if($k%2==0){
					$arr[$k/2]['start'] = $v;
				}else{
					$arr[$k/2]['end'] = $v;
				}
			}
			foreach ($arr as $key => $val){
				if($key==0){
					$arrstr .="[".json_encode($val).",";
				}else if($key==(count($arr)-1)){
					$arrstr .= json_encode($val)."]";
				}else{
					$arrstr .= json_encode($val).",";
				}
			}
			$arrstr = preg_replace('#.$#i', ']', $arrstr);
			//var_dump($arrstr);exit;
			$addsql = "update {$dbPrefix}shortcut set type = '$type',value = '$arrstr' where appid = '$appid'";
		}else{
			$addsql = "update {$dbPrefix}shortcut set type = '$type',value = '$value[0]' where appid = '$appid'";
		}
	}else{
		$response["result"] = 0;
		$response["msg"] = "该appid不存在";
	}
	
	if($conn->query($addsql)){
		$response["msg"] = "修改成功"; 
		$response["result"] = 1; //成功
	}
}else{
	$response["result"] = 0;//为空
	$response["msg"] = "参数不齐";
}


if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}

?>
