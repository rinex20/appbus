<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();

include("config/fg_config.php");


session_start();

$jsoncallback = C_GET("jsoncallback");
header('Content-Type: text/html; charset=utf-8');



$loginname = C_REQUEST('loginname');
$loginpass = C_REQUEST('loginpass');
//0:success;  1:invalid user  2:password error
$t_login = checkUserLogin($conn, $loginname, md5($loginpass));
$response["result"] = $t_login["result"];
$response["content"] = array();
if ($t_login["result"] == 0)
{
    $curTime = curTime();
    updateUserLogin($conn, $t_login["id"], $curTime);
    updateUserSession($conn, $t_login["id"], $curTime);

    $_SESSION[$fg_cfg["session"]["groupid"]] = $t_login["group_id"];
    $_SESSION[$fg_cfg["session"]["userid"]] = $t_login["id"];
    $_SESSION[$fg_cfg["session"]["username"]] = $t_login["loginname"];
    $sessionid = session_id();
    $_SESSION[$fg_cfg["session"]["sessionid"]] = $sessionid;

    //header("Location: main.php");
    $fg_cfg["session"]["flag"] = 1;

    $response["sessionid"] = $sessionid;
}elseif($t_login["result"] == 3){
	$curTime = curTime();
    updateUserLogin($conn, $t_login["id"], $curTime);
    updateUserSession($conn, $t_login["id"], $curTime);

    $_SESSION[$fg_cfg["session"]["groupid"]] = $t_login["group_id"];
    $_SESSION[$fg_cfg["session"]["userid"]] = $t_login["id"];
    $_SESSION[$fg_cfg["session"]["username"]] = $t_login["loginname"];
    $sessionid = session_id();
    $_SESSION[$fg_cfg["session"]["sessionid"]] = $sessionid;

    //header("Location: main.php");
    $fg_cfg["session"]["flag"] = 1;

    $response["sessionid"] = $sessionid;
}
//$json_result = formatJsonCHN(json_encode($response));
//echo $json_result;
//echo base64_encode(json_encode($response));
 if ($jsoncallback == ""){
    echo base64_encode($json_result);
    //echo $json_result;    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
} 

?>
