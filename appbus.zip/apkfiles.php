<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");
include("apkinfo.php");

$conn = connectdb();
$conn->query('SET NAMES utf8'); 
$conn->query("SET CHARACTER_SET_CLIENT=utf8");
$conn->query("SET CHARACTER_SET_RESULTS=utf8");
$android = new Service_Android();

foreach($_FILES as $postname => $file_info){
	if (empty($file_info["tmp_name"]))     continue;
	$file_info['name'] = preg_replace('# #', '', $file_info["name"]);
	if(!file_exists(UPLOAD_APK_PATH."/".$file_info["name"])){
		if(move_uploaded_file($file_info['tmp_name'], UPLOAD_APK_PATH."/".$file_info["name"])){
			$apk = UPLOAD_APK_PATH."/".$file_info["name"];
			$iconFile = UPLOAD_APK_PATH."/".$file_info["name"].".png";
			$exec = $android->getApkInfo($apk);
			$packageName = $exec['package']['name'];
			$appName = $exec['application']['label'];
			if($appName == ""){
				$appName = $exec['application']['label'];
			}
			
			//$appicon = $android->getFileFromApk($apk,$exec['application']['icon'],$iconFile);
			$appicon = $android->getFileFromApk($apk,$exec['application']['icon'],$iconFile);
			$versionName = $exec['package']['versionName'];
			$versionCode = $exec['package']['versionCode'];
			$res["packageName"] = $packageName;
			$res["appName"] = $appName;
			$res["apk"] = $apk;
			$res["appicon"] = UPLOAD_APK_HTTP."/".$file_info["name"].".png";
			//$res["appicon"] = UPLOAD_APK_HTTP.$iconFile;
			$res["versionName"] = $versionName;
			$res["versionCode"] = $versionCode;
		}
	}else{
			$apk = UPLOAD_APK_PATH."/".$file_info["name"];
			$iconFile = UPLOAD_APK_PATH."/".$file_info["name"].".png";
			$exec = $android->getApkInfo($apk);
			$packageName = $exec['package']['name'];
			$appName = $exec['application']['label'];
			$appicon = $android->getFileFromApk($apk,$exec['application']['icon'],$iconFile);
			$versionName = $exec['package']['versionName'];
			$versionCode = $exec['package']['versionCode'];
			$res["packageName"] = $packageName;
			$res["appName"] = $appName;
			$res["apk"] = $apk;
			//$res["appicon"] = UPLOAD_APK_HTTP.$iconFile;
			$res["appicon"] = UPLOAD_APK_HTTP."/".$file_info["name"].".png";
			$res["versionName"] = $versionName;
			$res["versionCode"] = $versionCode;
	}
	
} 


echo json_encode($res);


?>