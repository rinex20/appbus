<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");
include("config/fg_config.php");
$conn = connectdb();
include("config/fg_checksession.php");

if($_SESSION['appmanage_user_userid'] == "" || $_SESSION['appmanage_user_userid'] == null){
	header('location:login.php');
	exit();
}
$msg = "";
$login = C_POST('login');
if ($login == "login"){
	$loginname = C_POST('loginname');
	$loginpass = C_POST('loginpass');
	$t_login = checkUserLogin($conn, $loginname, md5($loginpass));
	if ($t_login["result"] == 0){
		$curTime = curTime();
		updateUserLogin($conn, $t_login["id"], $curTime);
		updateUserSession($conn, $t_login["id"], $curTime);
		$_SESSION[$fg_cfg["session"]["groupid"]] = $t_login["group_id"];
		$_SESSION[$fg_cfg["session"]["userid"]] = $t_login["id"];
		$_SESSION[$fg_cfg["session"]["username"]] = $t_login["loginname"];
		$sessionid = session_id();
		$_SESSION[$fg_cfg["session"]["sessionid"]] = $sessionid;
		$fg_cfg["session"]["flag"] = 1;
	}else if ($t_login["result"] == 1){
		$msg = "用户名错误";
	}else{
		$msg = "密码错误";
	}

}
?>

<!DOCTYPE html>
<html ng-app="AppStoreDemo" xmlns="http://www.w3.org/1999/xhtml" ng-controller="AppRootController">
<head>
<title>AppBus</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<META HTTP-EQUIV="pragma" CONTENT="no-cache"> 
<META HTTP-EQUIV="Cache-Control" CONTENT="no-cache, must-revalidate"> 
<META HTTP-EQUIV="expires" CONTENT="0">
<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="public/css/buttons.css">
<link rel="stylesheet" type="text/css" href="public/css/main.css">
<script type="text/javascript" src="app.config"></script>
<script src="public/js/jquery-2.1.1.min.js"></script>
<script src="public/js/bootstrap.js"></script>
<script src="public/js/angular.js"></script>
<script src="public/js/angular-route.min.js"></script>
<script src="public/js/ui-bootstrap-0.11.0.min.js"></script>
<script src="public/js/ui-bootstrap-tpls-0.11.0.min.js"></script>
<script src="public/js/main.js"></script>
<script src="app.js"></script>
<script src="public/js/ajaxfileupload.js"></script>
<!--[if IE]>
<style>.browsehappy{width:100%;height:100px;font-size:20px;line-height:100px;text-align:center;background-color: #E90D24;color: #DDD;}.browsehappy a{background-color: #31b0d5;border-color: #269abc;text-decoration: none;padding: 6px 12px;background-image: none;border: 1px solid transparent;border-radius: 4px;color: #fff;}</style>
<div class="browsehappy">IE浏览器不支持上传apk解析功能。请使用火狐浏览器或者谷歌浏览器！</div>
<![endif]-->
</head>
<body>

<div style="margin:0;">
  <div>
    <div ng-view style="width: 100%;height: 100%;margin: 0px;padding: 0px;"></div>
    <div class="col-md-2"></div>
  </div>
</div>
</body>
</html>
