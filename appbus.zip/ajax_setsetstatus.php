<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");
$conn = connectdb();
include("config/fg_config.php");
session_start();
$jsoncallback = C_GET("jsoncallback");
header('Content-Type: text/html; charset=utf-8');
$devicetype = C_REQUEST('devicetype');
$ifnotinlist = C_REQUEST('ifnotinlist');
$starts_check = C_REQUEST('starts_check');

$sql = "select * from {$dbPrefix}setstatus where sets = '$devicetype'";
$result = $conn->query($sql);
$rows_num = $result->rowCount();

if ($rows_num == 0 && $devicetype != "-- 请选择 --"){
    $sql = "insert into {$dbPrefix}setstatus(sets, status) values('$devicetype', '$ifnotinlist')";
	$result = $conn->exec($sql);
}
else{
    $sql = "update {$dbPrefix}setstatus set status = '$ifnotinlist' , starts = '$starts_check' where sets = '$devicetype'";
	$result = $conn->exec($sql);
}
$response["sql"] = $sql;

if ($result)
    $response["result"] = 0;
else
    $response["result"] = 1;


if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}

?>
