<?php

/*
//截取部分字符串，正确处理UTF8
substrUTF8($value, $start=0, $len=0, $ext="")

//取文件后缀
GetExt($filename)

//$_GET, replace
C_GET($str)

////$_POST, replace
C_POST($str)

//$_REQUEST, replace
C_REQUEST

//$_SESSION, replace
C_SESSION

//post data to mysql
formatInputData($data)

//get content from database
formatOutputData($str)

//check user has login
 checkUserLogin($conn, $loginname, $loginpass)

//check admin user login
 checkAdminLogin($conn, $loginname, $loginpass)

//current time
curTime()

//format datetime
showdate($timevalue, $format="yyyymmddhhiiss", $yf="-", $mf="-", $df=" ", $hf=":", $if=":", $sf="")

//将标准时间格式：yyyy-mm-dd hh:ii:ss时间变换为timestamp 14位时间
 disshowdate($timevalue)

//指定时间多少天之后或之前的时间
function nextdate($timevalue, $days, $years=0, $months=0, $hours=0, $mins=0, $secs=0)

//两个时间相差多少秒 
function disseconds($startdate, $enddate)

//返回指定目录下的文件列表, 去除指定文件
getFolderFiles($folder, $a_ignorefiles)

//draw grid table
drawGridData($colnum, $a_data, $bg0='#FFFFFF', $bg1='#FFFFFF', $tr_height=30)

//在数字前面按位数补0
changenum($number,$len)

//翻页列表 pageshownum:分页显示主体页码显示数量,适用奇数
 JumpPage($urlname, $varname, $varvale, $pagenum, $rownums, $pagerows=20, $pageshownum=5)

//产生随机字串，可用来自动生成密码, 默认长度6位 字母和数字混合, $format ALL NUMBER CHAR 字串组成格式
 randStr($len=6, $format='NUMBER') 

//当使用php自带的json_encode对数据进行编码时，中文都会变成unicode，导致不可读
formatJsonCHN($str)

//use phpmailer send mail
function SendMailByPhpMailer($toMail, $subject, $content)
*/


//截取汉字不会出现乱码的函数
function msubstr($str, $start, $len)
{
	$tmpstr = "";
	$strlen = $start + $len;

	for($i = 0; $i < $strlen; $i++)
	{
		if(ord(substr($str, $i, 1)) > 0xa0)
		{
			$tmpstr .= substr($str, $i, 2);
			$i++;
		}
		else
			$tmpstr .= substr($str, $i, 1);
	}
	return $tmpstr;
}

function c_substr($value, $start=0, $len=0, $ext="")
{
	$value_len = strlen($value);

	if ($value_len > $len)
	{
		$result = msubstr($value, $start, $len).$ext;
	}
	else
	{
		$result = msubstr($value, $start, $len);
	}

	return $result;
}

function msubstrUTF8($str, $start, $len)
{
	$tmpstr = "";
	$iChars = 0;
	$iIndex = $start;

	while ($iChars < $len)
	{
		if(ord(substr($str, $iIndex, 1)) > 0xa0)
		{
			$tmpstr .= substr($str, $iIndex, 3);
			$iIndex = $iIndex + 3;
			$iChars = $iChars + 2;
		}
		else
		{
			$tmpstr .= substr($str, $iIndex, 1);
			$iIndex = $iIndex + 1;
			$iChars = $iChars + 1;
		}
	}


	return $tmpstr;
}


function substrUTF8($value, $start=0, $len=0, $ext="")
{
	$value_len = strlen($value);

	if ($value_len > $len)
	{
		$result = msubstrUTF8($value, $start, $len).$ext;
	}
	else
	{
		$result = msubstrUTF8($value, $start, $len);
	}

	return $result;
}


function GetExt($filename)
{
	$pos = strrpos($filename, '.');
	if ($pos == "")
		return "";

	$ext = substr($filename, $pos+1);

	return $ext;
}


function C_GET($str, $default_value=""){
    $val = isset($_GET[$str]) ? $_GET[$str] : $default_value;
    return $val;
}

function C_POST($str, $default_value=""){
    $val = isset($_POST[$str]) ? $_POST[$str] : $default_value;
    return $val;
}

function C_REQUEST($str, $default_value=""){
    $val = isset($_REQUEST[$str]) ? $_REQUEST[$str] : $default_value;
    return $val;
}

function C_SESSION($str, $default_value=""){
    $val = isset($_SESSION[$str]) ? $_SESSION[$str] : $default_value;
    return $val;
}

function formatInputData($data)
{
	//$result = mysql_escape_string($data);	
	$result = mysql_real_escape_string($data);	
	return $result;
}

function formatOutputData($str)
{
	$result = htmlspecialchars($str, ENT_QUOTES);

	$order   = array('\r\n', '\n', '\r');
	$replace = '<br />';
	$result = str_replace($order, $replace, $result);
	
	$result = nl2br($result);
	return $result;
}



function formatInputToDB($data){
  if(!get_magic_quotes_gpc()) {  //只对POST/GET/cookie过来的数据增加转义
    $data = is_array($data)?array_map('addslashes',$data):addslashes($data);
  } else {
    $data = stripslashes($data);
  }

  $data = mysql_real_escape_string($data);
  return $data;
}

function formatOutputFromDB($str)
{
	$result = htmlspecialchars(stripslashes($str));
	//$result = htmlspecialchars($str);
	return $result;
}

function curTime()
{
	return date("YmdHis", time());
}

//将timestamp时间变换为标准时间格式：yyyy-mm-dd hh:ii:ss
function showdate($timevalue, $format="yyyymmddhhiiss", $yf="-", $mf="-", $df=" ", $hf=":", $if=":", $sf="")
{
	if (strlen($timevalue) != 14)	return $timevalue;
	
    $year = substr($timevalue,0,4);
    $month = substr($timevalue,4,2);
    $day = substr($timevalue,6,2);
    $hour = substr($timevalue,8,2);
    $min = substr($timevalue,10,2);
    $sec = substr($timevalue,12,2);

    $result = "";

    if (substr($format, 0, 4) == "yyyy")		$result = $year;
    if (substr($format, 4, 2) == "mm")			$result .= $yf.$month;
    if (substr($format, 6, 2) == "dd")			$result .= $mf.$day;
    if (substr($format, 8, 2) == "hh")			$result .= $df.$hour;
    if (substr($format, 10, 2) == "ii")			$result .= $hf.$min;
    if (substr($format, 12, 2) == "ss")			$result .= $if.$sec.$sf;

    return $result;
}


//将标准时间格式：yyyy-mm-dd hh:ii:ss时间变换为timestamp 14位时间
function disshowdate($timevalue)
{
    $year = substr($timevalue, 0, 4);
    $month = substr($timevalue, 5, 2);
    $day = substr($timevalue, 8, 2);
    $hour = substr($timevalue, 11, 2);
    $min = substr($timevalue, 14, 2);
    $sec = substr($timevalue, 17, 2);

    return $year.$month.$day.$hour.$min.$sec;
}


function getFolderFiles($folder, $a_ignorefiles=array())
{
	$files = array();
	if($handle = opendir($folder))
	{
		//echo "Files:\n";
		while (false !== ($file = readdir($handle)))
		{
			if ($file!= "." && $file!=".." && !is_dir($file) && !in_array($file, $a_ignorefiles))
				$files[] = $file;
		}
		closedir($handle);
	}
	return $files;
}


//指定时间多少天之后或之前的时间
function nextdate($timevalue, $days, $years=0, $months=0, $hours=0, $mins=0, $secs=0)
{
    if ($timevalue == 0)
    {
    	$mktimes = mktime(date(H)+$hours, date(i)+$mins, date(s)+secs, date("m")+$months, date("d")+$days, date("Y")+$years);
        $timearray = getdate($mktimes);
    }
    else
    {
        $curyear = substr($timevalue,0,4);
        $curmonth = substr($timevalue,4,2);
        $curday = substr($timevalue,6,2);
        $curhour = substr($timevalue,8,2);
        $curmin = substr($timevalue,10,2);
        $cursec = substr($timevalue,12,2);
        $mktimes = mktime($curhour+$hours, $curmin+$mins, $cursec+$secs, $curmonth+$months, $curday+$days, $curyear+$years);
        $timearray = getdate($mktimes);
    }

    $year = changenum($timearray["year"],4);
    $month = changenum($timearray["mon"],2);
    $day = changenum($timearray["mday"],2);
    $hour = changenum($timearray["hours"],2);
    $min = changenum($timearray["minutes"],2);
    $sec = changenum($timearray["seconds"],2);
    $curenttime = $year.$month.$day.$hour.$min.$sec;

    return $curenttime;
}

//两个时间相差多少秒 
function disseconds($startdate, $enddate)
{
    $endyear = substr($enddate,0,4);
    $endmonth = substr($enddate,4,2);
    $endday = substr($enddate,6,2);
    $endhour = substr($enddate,8,2);
    $endminute = substr($enddate,10,2);
    $endsecond = substr($enddate,12,2);

    $startyear = substr($startdate,0,4);
    $startmonth = substr($startdate,4,2);
    $startday = substr($startdate,6,2);
    $starthour = substr($startdate,8,2);
    $startminute = substr($startdate,10,2);
    $startsecond = substr($startdate,12,2);

    $endmktime = mktime($endhour, $endminute, $endsecond, $endmonth, $endday, $endyear);
    $startmktime = mktime($starthour, $startminute, $startsecond, $startmonth, $startday, 0+$startyear);
    //echo "endmktime = ".$endmktime.", startmktime = ".$startmktime."<br>\n";

    $dismktime = $endmktime - $startmktime;

    return $dismktime;
}

function drawGridData($colnum, $a_data, $bg0='#FFFFFF', $bg1='#FFFFFF', $tr_height=30)
{
	//echo "bg0 = ".$bg0.", bg1 = ".$bg1."<br>\n";
	$res = "";
	
	$count = count($a_data);
	for ($i=0; $i<$count; $i++)
	{		
		if ($i % $colnum == 0 && $i != 0)		echo "</tr>\n";
		if ($i % $colnum == 0){
			//echo "rows = ".(($i/$colnum)%2)."<br>\n";
			if (($i/$colnum)%2 == 0)	echo "<tr height='$tr_height' style='background-color:$bg0;'>";
			else 						echo "<tr height='$tr_height' style='background-color:$bg1;'>";
		}


		echo "<td>".$a_data[$i]."</td>";
	}
	
	//echo $i."\n";
	if ($i%$colnum == 0)
		echo "</tr>\n";
	else
	{
		for ($j=$i%$colnum; $j<$colnum; $j++)
		{ 
			echo "<td>&nbsp;</td>";
			if ($j==$colnum-1)	echo "</tr>\n";
		}
	}
}

//在数字前面按位数补0
function changenum($number,$len)
{
	return ($len>0?sprintf("%0$len"."s",$number):"$number");
}

function UploadFile($File, $filename, $subpath)
{   
	//echo "File=".$File['name']."<br>";
	if ($File['name'] == "")
		return "emptyimage";
	
	//global $UPLOADABSPATH;	
	$UPLOADABSPATH = UPLOAD_ABSPATH;
	//get upload file
	//$File = $HTTP_POST_FILES['UploadFile1'];
	$UploadFile = $File['tmp_name'];
	$Uploadfilename = $File['name'];
	$UploadFile_size = $File['size'];
	//$ip=$HTTP_SERVER_VARS[REMOTE_ADDR];	

	$TimeLimit=3600; 
	set_time_limit($TimeLimit);
	
	$uploadFlag = 0;
	if(($UploadFile != "none")&&($UploadFile != ""))
	{
		$UploadPath = $UPLOADABSPATH.$subpath;   //上载档存放路径
		$FileName = $UploadPath.$filename.".".GetExt($Uploadfilename); //上载档案名
    	/*if(!rename($UploadFile,$FileName))    
     		return "errorimage";
     	else
     		chmod($FileName, 0644);
     		*/
     	move_uploaded_file($UploadFile, $FileName);
	}
	else
		return "errorimage";
	
	return $Uploadfilename;
}

function JumpPage($urlname, $varname, $varvale, $pagenum, $rownums, $pagerows=20, $pageshownum=5)
{
	$t_request = "";
	for ($i=0; $i<count($varname); $i++)
		$t_request .= "&".$varname[$i]."=".$varvale[$i];

	$prepage = $pagenum - 1;
	$nextpage = $pagenum + 1;

	$content = "";
	$content = "<div class='changepage'>";

	$total_pages = ceil($rownums / $pagerows);
	switch ($total_pages) {
		case 0:
		case 1:
			break;
		case 2:
		case 3:
		case 4:
		case 5:
			if ($pagenum == 1)
				$content.= "<span class='disabled'> < </span>";
			else
				$content.= "<a href='".$urlname."?pagenum=$prepage".$t_request."'> < </a>";

			for ($i=1; $i<=$total_pages; $i++){
				if ($pagenum == $i)
					$content.= "<span class='current'>$i</span>";
				else
					$content.= "<a href='".$urlname."?pagenum=$i".$t_request."'>$i</a>";
			}

			if ($pagenum == $total_pages)
				$content.= "<span class='disabled'> > </span>";
			else
				$content.= "<a href='".$urlname."?pagenum=$nextpage".$t_request."'> > </a>";

			break;		
		default:
			$half_pageshownum = floor($pageshownum / 2);
			$startpage = ($pagenum <= ($total_pages - $half_pageshownum)) ? ((($pagenum-$half_pageshownum) < 1) ? 1 : ($pagenum - $half_pageshownum)) : ($total_pages - $pageshownum + 1);
			$endpage = $startpage + $pageshownum - 1;

			if ($pagenum == 1)
				$content.= "<span class='disabled'> < </span>";
			else
				$content.= "<a href='".$urlname."?pagenum=$prepage".$t_request."'> < </a>";

			if ($startpage != 1){
				$content.= "<a href='".$urlname."?pagenum=1".$t_request."'>1</a>";
				$content.= "...";
			}
			
			for ($i=$startpage; $i<=$endpage; $i++){
				if ($pagenum == $i)
					$content.= "<span class='current'>$i</span>";
				else
					$content.= "<a href='".$urlname."?pagenum=$i".$t_request."'>$i</a>";
			}

			if ($endpage != $total_pages){
				$content.= "...";
				$content.= "<a href='".$urlname."?pagenum=$total_pages".$t_request."'>$total_pages</a>";
			}

			if ($pagenum == $total_pages)
				$content.= "<span class='disabled'> > </span>";
			else
				$content.= "<a href='".$urlname."?pagenum=$nextpage".$t_request."'> > </a>";

			break;
	}
	$content.= "</div>";

	return $content;

}

#-------------------------------------------
# 产生随机字串，可用来自动生成密码 
# 默认长度6位 字母和数字混合
# $format ALL NUMBER CHAR 字串组成格式
#-------------------------------------------
function randStr($len=6, $format='NUMBER') 
{ 
	switch($format) 
	{ 
	case 'ALL':
		$chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-@#~'; 
		break;
	case 'CHAR':
		$chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-@#~'; 
		break;
	case 'BIGCHARNUMBER':
		$chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; 
		break;
	case 'NUMBER':
		$chars='0123456789'; 
		break;
	default :
		$chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-@#~'; 
		break;
	}
	
	mt_srand((double)microtime()*1000000*getmypid()); 
	
	$password="";	
	while(strlen($password) < $len)
		$password .= substr($chars, (mt_rand()%strlen($chars)), 1);
	
	return $password;
}


function formatJsonCHN($str){
	return preg_replace("#\\\u([0-9a-f]{4})#ie", "iconv('UCS-2BE', 'UTF-8', pack('H4', '\\1'))", $str);
}


function SendMailByPhpMailer($toMail, $subject, $content){
    global $common_cfg;

    $mail = new PHPMailer;

    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->CharSet = $common_cfg["mailserver"]["CharSet"];

    $mail->Host = $common_cfg["mailserver"]["Host"];  // Specify main and backup SMTP servers
    $mail->SMTPAuth = $common_cfg["mailserver"]["SMTPAuth"];                               // Enable SMTP authentication
    $mail->Username = $common_cfg["mailserver"]["Username"];                 // SMTP username
    $mail->Password = $common_cfg["mailserver"]["Password"];                           // SMTP password
    $mail->SMTPSecure = $common_cfg["mailserver"]["SMTPSecure"];                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = $common_cfg["mailserver"]["Port"];                                    // TCP port to connect to

    $mail->From = $common_cfg["mailserver"]["From"];
    $mail->FromName = $common_cfg["mailserver"]["FromName"];
    
    $mail->addAddress($toMail);
    $mail->addReplyTo($common_cfg["mailserver"]["addReplyTo"]);
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
    $mail->isHTML($common_cfg["mailserver"]["isHTML"]);                                  // Set email format to HTML

    $mail->Subject = $subject;
    $mail->Body    = $content;
    $mail->AltBody = $common_cfg["mailserver"]["AltBody"];

    if(!$mail->send()) {
        //echo 'Message could not be sent.';
        //echo 'Mailer Error: ' . $mail->ErrorInfo;
        return -1;
    } else {
        //echo 'Message has been sent';
        return 0;
    }

/*
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->CharSet='UTF-8';

    $mail->Host = 'smtp.exmail.qq.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'postmaster@vankoo.com.cn';                 // SMTP username
    $mail->Password = 'vankoo2015';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to

    $mail->From = 'postmaster@vankoo.com.cn';
    $mail->FromName = 'postmaster';
    $mail->addAddress('arthur_cai@126.com', 'Joe User');     // Add a recipient
    $mail->addAddress('jcai@actiontec.com');               // Name is optional
    $mail->addReplyTo('arthur_cai@126.com', 'Information');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
    $mail->isHTML(true);                                  // Set email format to HTML

    $mail->Subject = $subject;
    $mail->Body    = $content;
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    if(!$mail->send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    } else {
        echo 'Message has been sent';
    }
*/
}
//来访者IP
function get_real_ip()
{
       $ip=false;
       if(!empty($_SERVER["HTTP_CLIENT_IP"]))
       {
            $ip = $_SERVER["HTTP_CLIENT_IP"];
       }
       if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
       {
            $ips = explode (", ", $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip)
            {
                     array_unshift($ips, $ip); $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++)
            {
                     if (!eregi ("^(10|172\.16|192\.168)\.", $ips[$i]))
                     {
                               $ip = $ips[$i];
                               break;
                     }
            }
       }
       return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
}

//判断IP段
function ip_in_network($ip, $network)
{
    $ip = (double) (sprintf("%u", ip2long($ip)));
    $s = explode('/', $network);
    $network_start = (double) (sprintf("%u", ip2long($s[0])));
    $network_len = pow(2, 32 - $s[1]);
    $network_end = $network_start + $network_len - 1;
 
    if ($ip >= $network_start && $ip <= $network_end)
    {
        return true;
    }
    return false;
}

function str_change($data) {
    //去除一个字符串反斜杠，
    $data=stripslashes($data);
    //去除一个字符串两端空格，
    $data=trim($data);
    //解码
    $data=json_decode($data,true);
    return $data;
}
 

//对应的方法
function is_ip($localIp,$ipRanges) 
 {
 $localIp = ip2long($localIp);   
   foreach($ipRanges as $val) 
 {  
 $ipmin=sprintf("%u",ip2long($val[0]));
 $ipmax=sprintf("%u",ip2long($val[1]));
 if($localIp >= $ipmin && $localIp <= $ipmax) {
 	   return $val;   
 	}  
 }    
 return false; 
 }


//当前url地址和端口
$url ='http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/upload'; 
?>