<?php
define('DB_DBMS', 'mysql');
define('DB_NAME', 'appbus_168fapai_');
define('DB_USER', 'appbus_168fapai_');
define('DB_PASSWORD', 'JiAJ2sARSyA64weD');
define('DB_HOST', 'localhost');
define('DB_DSN', 'mysql:host=localhost;dbname=appbus_168fapai_');

define('ROOT_HTDOCS', 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"]);
define('UPLOAD_HTTP', 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/upload');
define('UPLOAD_APK_HTTP', 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/upload/apkinfo');
define('UPLOAD_ABSPATH', '/www/wwwroot/appbus.168fapai.com/upload');
define('UPLOAD_APK_PATH', '/www/wwwroot/appbus.168fapai.com/upload/apkinfo');

?>
