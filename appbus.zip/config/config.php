<?php
define('DB_DBMS', 'mysql');
define('DB_NAME', 'appbus');
define('DB_USER', 'appbus');
define('DB_PASSWORD', '3TmLb6my4HwbcTsi');
define('DB_HOST', 'localhost');
define('DB_PREFIX', 'apps_');
define('DB_DSN', 'mysql:host=localhost;dbname=appbus');
$dbPrefix = "apps_";

define('ROOT_DIV', dirname(dirname(__FILE__)));
define('ROOT_HTDOCS', 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"]);
define('UPLOAD_HTTP', 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/upload');
define('UPLOAD_APK_HTTP', 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/upload/apkinfo');
define('UPLOAD_ABSPATH', ROOT_DIV.'/upload');
define('UPLOAD_APK_PATH', ROOT_DIV.'/upload/apkinfo');


$common_cfg["upload_folder"]["appfiles"] = "/appfiles/";
$common_cfg["upload_folder"]["appshotscreen"] = "/appshotscreen/";



?>
