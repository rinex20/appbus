<?php
/*
//connect to db, return $conn
function connectdb()

//check user has login
function checkUserLogin($conn, $loginname, $loginpass)

//check admin user login
function checkAdminLogin($conn, $loginname, $loginpass)

//modify last login 
updateAdminLogin($conn, $user_id, $curtime)

//check user login with email
function checkUserLoginWithEmail($conn, $email, $loginpass)

//modify last login 
updateUserLogin($conn, $user_id, $curtime)


//admin user whether already registered, 0:not registered; >0 registered
adminAlreadyRegistered($conn, $username)

//website user whether already registered, 0:not registered; >0 registered
userAlreadyRegistered($conn, $username)

//website email whether already registered, 0:not registered; >0 registered
emailAlreadyRegistered($conn, $email)

//get table AUTO_INCREMENT id
getTableAutoIncrementID($conn, $table, $defaultid=10000001)

//insert into table
c_insertDB($conn, $table);

//update table
c_updateDB($conn, $table, $key_values, $where);

//delete table
c_deleteDB($conn, $table, $where)


//check session table
checkAdminSession($conn, $admin_id, $session_timeout);

//update admin session table, modify lastvisittime
function updateAdminSession($conn, $admin_id, $curtime);

//check user session
checkUserSession($conn, $user_id, $session_timeout);

//update user session table, modify lastvisittime
function updateUserSession($conn, $user_id, $curtime);


//check app user session
checkAppSession($conn, $user_id, $session_timeout);

//update app user session table, modify lastvisittime
function updateAppSession($conn, $user_id, $curtime);


//change user password with app
function changePwdWithApp($conn, $user_id, $oldpwd, $newpwd);


/*
result	0:success;	1:invalid user	2:password error
*/

function connectdb(){
	try {
		$conn = new PDO(DB_DSN, DB_USER, DB_PASSWORD); //初始化一个PDO对象
	} catch (PDOException $e) {
		die ("Error!: " . $e->getMessage() . "<br/>");
	}
	$conn->query('SET NAMES utf8'); 
	$conn->query("SET CHARACTER_SET_CLIENT=utf8");
	$conn->query("SET CHARACTER_SET_RESULTS=utf8");
	return $conn;
}

/*
result	0:success;	1:invalid user	2:password error
*/
function checkAdminLogin($conn, $loginname, $loginpass)
{

	$sql = "select * from c_admin where isdeleted = 0 and  active = 1 and username = '$loginname'";
	//$result = mysql_query($sql, $conn);
	$result = $conn->query($sql);
	if($row = $result->fetch())
	{
		$res = $row;
	}
	else
	{
		$res["result"] = 1;
		return $res;
	}

	if (md5($loginpass) == $res["userpass"])
		$res["result"] = 0;
	else
		$res["result"] = 2;

	return $res;
}

function updateAdminLogin($conn, $user_id, $curtime)
{
	$sql = "update c_admin set lastlogin = '$curtime' where id = $user_id";
	//mysql_query($sql, $conn);
	$conn->query($sql);
}


function adminAlreadyRegistered($conn, $username){
	$sql = "select * from c_admin where username = '$username'";
	//echo $sql."<br>\n";
	/* $result = mysql_query($sql);
	$num = mysql_num_rows($result); */
	$num = $conn->query($sql);
	//$num = $result->rowCount();
	return $num;
}


function userAlreadyRegistered($conn, $username){
	$sql = "select * from apps_users where loginname = '$username'";
	//echo $sql."<br>\n";
	/* $result = mysql_query($sql);
	$num = mysql_num_rows($result); */
	$num = $conn->query($sql);
	//$num = $result->rowCount();
	return $num;
}

function emailAlreadyRegistered($conn, $email){
	$sql = "select * from apps_users where email = '$email'";
	/* $result = mysql_query($sql);
	$num = mysql_num_rows($result); */
	$num = $conn->query($sql);
	//$num = $result->rowCount();
	return $num;
}

function mobileAlreadyRegistered($conn, $mobile){
	$sql = "select COUNT(*) from apps_users where mobile = '$mobile'";
/* 	$result = mysql_query($sql);
	$num = mysql_num_rows($result); */
	$num = $conn->query($sql);
	//$num = $result->rowCount();
	return $num;
}

function nicknameAlreadyRegistered($conn, $nickname){
	$sql = "select * from apps_users where nickname = '$nickname'";
	/* $result = mysql_query($sql);
	$num = mysql_num_rows($result); */
	$conn->query($sql);
	$num = $conn->query($sql);
	//$num = $result->rowCount();
	return $num;
}

/*
result	0:success;	1:invalid user	2:password error
*/
function checkUserLogin($conn, $loginname, $loginpass)
{
	$sql = "select * from apps_users where isdeleted = 0 and  active = 1 and loginname = '$loginname'";
	//echo $sql."<br>";
	/* $result = mysql_query($sql, $conn);
	if ($row = mysql_fetch_array($result))
	{
    	$res = $row;
    } */

	$result = $conn->query($sql);
	if($row = $result->fetch())
	{
		$res = $row;
		
	}
	else
	{
		$res["result"] = 1;
		return $res;
	}
	if (strtolower($loginpass) == strtolower($res["loginpass"]))
		$res["result"] = 0;
	else
		$res["result"] = 2;

	return $res;
}

/*
result	0:success;	1:invalid user	2:password error
*/
function checkUserLoginWithEmail($conn, $email, $loginpass)
{
	$sql = "select * from apps_users where isdeleted = 0 and  active = 1 and email = '$email'";
	/* $result = mysql_query($sql, $conn);
	if ($row = mysql_fetch_array($result))
	{
    	$res = $row;
    } */
	$result = $conn->query($sql);
	if($row = $result->fetch())
	{
		$res = $row;
	}
	else
	{
		$res["result"] = 1;
		return $res;
	}
	if (strtolower($loginpass) == strtolower($res["loginpass"]))
		$res["result"] = 0;
	else
		$res["result"] = 2;

	return $res;
}

/*
result	0:success;	1:invalid user	2:password error
*/
function checkUserLoginWithNickname($conn, $nickname, $loginpass)
{
	$sql = "select * from apps_users where isdeleted = 0 and  active = 1 and nickname = '$nickname'";
	/* $result = mysql_query($sql, $conn);
	if ($row = mysql_fetch_array($result))
	{
    	$res = $row;
    } */
	$result = $conn->query($sql);
	if($row = $result->fetch())
	{
		$res = $row;
	}
	else
	{
		$res["result"] = 1;
		return $res;
	}

	if (strtolower($loginpass) == strtolower($res["loginpass"]))
		$res["result"] = 0;
	else
		$res["result"] = 2;

	return $res;
}

function UpdatePass($conn, $loginname, $loginpass,$xgpassword)
{
	$sql = "update  apps_users set loginpass='$xgpassword' where  id ='2'";
	/* $result = mysql_query($sql, $conn);
	if ($row = mysql_fetch_array($result))
	{
    	$res = $row;
		$res["result"] = 0;
    } */
	$result = $conn->query($sql);
	if($row = $result->fetch())
	{
		$res = $row;
		$res["result"] = 0;
	}
	else
	{
		$res["result"] = 1;
		return $res;
	}
	return $res;
}

function UpdateInitialize($conn, $loginname, $loginpass,$xgpassword)
{
	$sql = "update  apps_users set loginpass='$xgpassword' where  id ='2'";
	/* $result = mysql_query($sql, $conn);

	if ($row = mysql_fetch_array($result))
	{
    	$res = $row;
		$res["result"] = 0;
    } */
	$result = $conn->query($sql);
	if($row = $result->fetch())
	{
		$res = $row;
		$res["result"] = 0;
	}
	else
	{
		$res["result"] = 1;
		return $res;
	}
	return $res;
}


/*
result	0:success;	1:invalid user	2:password error
*/
function checkUserLoginWithMobile($conn, $mobile, $loginpass)
{
	$sql = "select * from apps_users where isdeleted = 0 and  active = 1 and mobile = '$mobile'";
	/* $result = mysql_query($sql, $conn);
	if ($row = mysql_fetch_array($result))
	{
    	$res = $row;
    } */
	$result = $conn->query($sql);
	if($row = $result->fetch())
	{
		$res = $row;
		$res["result"] = 0;
	}
	else
	{
		$res["result"] = 1;
		return $res;
	}
	
	if (strtolower($loginpass) == strtolower($res["loginpass"]))
		$res["result"] = 0;
	else
		$res["result"] = 2;

	return $res;
}

function updateUserLogin($conn, $user_id, $curtime)
{
	$sql = "update apps_users set lastlogintime = '$curtime', logincount = logincount+1 where id = $user_id";
	//mysql_query($sql, $conn);
	$conn->query($sql);
}


function getTableAutoIncrementID($conn, $table, $defaultid=10000001){
	$sql = "select * from $table order by id desc limit 1";
	//$result = mysql_query($sql);
	$result = $conn->query($sql);
	$tmpid = $defaultid;
	if($row = $result->fetch())
	{
		$tmpid = $row["id"] + 1;
	}

/* 	if ($row = mysql_fetch_array($result))
	{
		$tmpid = $row["id"] + 1;
	} */

	return $tmpid;
}


function c_insertDB($conn, $table, $fields, $values) {
	function formatdata($value)
	{
	    return "'".formatInputToDB($value)."'";
	}
	$values = array_map("formatdata", $values);

	$sql = "insert into $table (".implode(",", $fields).") ";
	$sql.= "values (".implode(",", $values).") ";
	//$result = mysql_query($sql, $conn);
	$result = $conn->exec($sql);

	return $result;
}

function c_updateDB($conn, $table, $key_values, $where) {
	$sql = "update $table set ";

	$idx = 0;
	foreach ($key_values as $key => $value) {
		if ($idx != 0)	$sql.= ",";
		$sql.= $key." = '".formatInputToDB($value)."' ";
		$idx ++;
	}


	$sql.= $where;

	//$result = mysql_query($sql, $conn);
	$result = $conn->exec($sql);
	return $result;
}

function c_deleteDB($conn, $table, $where){
	$sql = "delete from $table $where";
	//$result = mysql_query($sql, $conn);
	$result = $conn->exec($sql);
	return $result;
}


//1: succ;	0:fail
function checkAdminSession($conn, $admin_id, $session_timeout){
	if (!isset($admin_id) || !is_numeric($admin_id))	return 0;
	$res = 0;

	$sql = "select * from c_adminsession where admin_id = $admin_id";
	//$result = mysql_query($sql, $conn);
	$result = $conn->query($sql);
	if($row = $result->fetch())
	{
		$id = $rows["id"];
		$lastvisittime = $rows["lastvisittime"];
		$curtime = curTime();		
		$disseconds = disseconds($lastvisittime, $curtime);
		if ($disseconds > $session_timeout)	return 0;
		$res = 1;
		updateAdminSession($conn, $admin_id, $curtime);
	}
	/* if ($rows = mysql_fetch_array($result)){
		$id = $rows["id"];
		$lastvisittime = $rows["lastvisittime"];

		$curtime = curTime();		
		$disseconds = disseconds($lastvisittime, $curtime);
		//echo "lastvisittime = ".$lastvisittime.", curtime = ".$curtime.", disseconds = ".$disseconds."<br>\n";
		if ($disseconds > $session_timeout)	return 0;

		$res = 1;
		updateAdminSession($conn, $admin_id, $curtime);
	} */

	return $res;
}

function updateAdminSession($conn, $admin_id, $curtime){
	$sql = "INSERT INTO c_adminsession (admin_id, lastvisittime) VALUES ($admin_id, '$curtime') ";
	$sql.= "ON DUPLICATE KEY UPDATE lastvisittime = '$curtime'";
	//mysql_query($sql, $conn);
	$conn->exec($sql);
}


//1: succ;	0:fail
function checkUserSession($conn, $user_id, $session_timeout){
	//echo "user_id = ".$user_id.", timeout = ".$session_timeout."<br>\n";
	if (!isset($user_id) || !is_numeric($user_id))	return 0;
	$res = 0;

	$sql = "select * from apps_usersession where user_id = $user_id";
	$result = $conn->query($sql);
	if($row = $result->fetch())
	{
		$id = $rows["id"];
		$lastvisittime = $rows["lastvisittime"];
		$curtime = curTime();		
		$disseconds = disseconds($lastvisittime, $curtime);
		if ($disseconds > $session_timeout)	return 0;
		$res = 1;
		updateUserSession($conn, $user_id, $curtime);
	}
	//$result = mysql_query($sql, $conn);
	/* if ($rows = mysql_fetch_array($result)){
		$id = $rows["id"];
		$lastvisittime = $rows["lastvisittime"];

		$curtime = curTime();		
		$disseconds = disseconds($lastvisittime, $curtime);
		//echo "lastvisittime = ".$lastvisittime.", curtime = ".$curtime.", disseconds = ".$disseconds."<br>\n";
		if ($disseconds > $session_timeout)	return 0;

		$res = 1;
		updateUserSession($conn, $user_id, $curtime);
	} */

	return $res;
}

function updateUserSession($conn, $user_id, $curtime){
	$sql = "select * from apps_usersession where user_id = $user_id";
	//$result = mysql_query($sql, $conn);
	$result = $conn->query($sql);
	if($row = $result->fetch()){
		$sql = "update apps_usersession set lastvisittime = '$curtime' where user_id = $user_id";
		$conn->exec($sql);
	}else{
		$sql = "INSERT INTO apps_usersession (user_id, lastvisittime) VALUES ($user_id, '$curtime') ";
		$conn->exec($sql);
	}
/* 	if ($rows = mysql_fetch_array($result)){		
		$sql = "update apps_usersession set lastvisittime = '$curtime' where user_id = $user_id";
		mysql_query($sql, $conn);
	}else{
		$sql = "INSERT INTO apps_usersession (user_id, lastvisittime) VALUES ($user_id, '$curtime') ";
		//echo $sql."<br>\n";
		mysql_query($sql, $conn);
	} */
}



//1: succ;	0:fail
function checkAppSession($conn, $user_id, $session_timeout){
	//echo "user_id = ".$user_id.", timeout = ".$session_timeout."<br>\n";
	if (!isset($user_id) || !is_numeric($user_id))	return 0;
	$res = 0;

	$sql = "select * from apps_usersession where user_id = $user_id";
	//$result = mysql_query($sql, $conn);
	$result = $conn->query($sql);
	if($row = $result->fetch())
	{
		$id = $rows["id"];
		$lastvisittime = $rows["lastvisittime"];
		$curtime = curTime();		
		$disseconds = disseconds($lastvisittime, $curtime);
		if ($disseconds > $session_timeout)	return 0;
		$res = 1;
		$sql = "update apps_usersession set lastvisittime = '$curtime' where user_id = $user_id";
		$conn->exec($sql);
	}
	/* if ($rows = mysql_fetch_array($result)){
		$id = $rows["id"];
		$lastvisittime = $rows["lastvisittime"];

		$curtime = curTime();		
		$disseconds = disseconds($lastvisittime, $curtime);
		//echo "lastvisittime = ".$lastvisittime.", curtime = ".$curtime.", disseconds = ".$disseconds."<br>\n";
		if ($disseconds > $session_timeout)	return 0;

		$res = 1;
		//updateAppSession($conn, $user_id, $curtime);
		$sql = "update apps_usersession set lastvisittime = '$curtime' where user_id = $user_id";
		//echo $sql."<br>\n";
		mysql_query($sql, $conn);
	} */


	return $res;
}



//0: succ;	1:old password error;	2:fail
function changePwdWithApp($conn, $user_id, $oldpwd, $newpwd){
	$sql = "select * from apps_users where isdeleted = 0 and  active = 1 and id = $user_id and loginpass = '$oldpwd'";
	//echo $sql."<br>";
	//$result = mysql_query($sql, $conn);
	//$num = mysql_num_rows($result);
	$result = $conn->query($sql);
	$num = $result->rowCount(); 
	if ($num == 0)	return 1;

	$curtime = curTime();
	$sql = "update apps_users set loginpass = '$newpwd', lastmodifydate = '$curtime' where id = $user_id";
	//$result = mysql_query($sql, $conn);
	$result = $conn->exec($sql);
	if ($result){
		return 0;
	}

	return 2;
}

?>