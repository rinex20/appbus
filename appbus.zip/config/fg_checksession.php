<?php
session_start();
$fg_cfg["session"]["flag"] = checkUserSession($conn, C_SESSION($fg_cfg["session"]["userid"]), $fg_cfg["session"]["timeout"]);
?>