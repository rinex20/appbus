<?php
//session timeout value seconds
$fg_cfg["session"]["timeout"] = 86400;
$fg_cfg["session"]["defaulttime"] = "19700101000000";

//session key
$fg_cfg["session"]["groupid"] = "appmanage_user_groupid";
$fg_cfg["session"]["userid"] = "appmanage_user_userid";
$fg_cfg["session"]["username"] = "appmanage_user_username";
$fg_cfg["session"]["pagenum"] = "appmanage_user_pagenum";

$fg_cfg["session"]["sessionid"] = "appmanage_user_pagenum";

$fg_cfg["session"]["flag"] = 0;

$host=$_SERVER["SERVER_ADDR"];

?>