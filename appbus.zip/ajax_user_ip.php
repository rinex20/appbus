<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();

include("config/fg_config.php");

session_start();

$jsoncallback = C_GET("jsoncallback");

header('Content-Type: text/html; charset=utf-8');

$textstartip = C_REQUEST('textstartip');
$textendip = C_REQUEST('textendip');
$textstartip = trim($textstartip);
$textendip = trim($textendip);
if($textstartip != "" && $textendip != ""){
	$sql = "select * from apps_reip";
	$result = $conn->query($sql);
	
	$sqlselect = "select * from {$dbPrefix}reip where getleftip = '$textstartip' and getrightip = '$textendip'";
	$results = $conn->query($sqlselect);
	if($results->rowCount()){
		$addsql = "delete from {$dbPrefix}reip where getleftip = '$textstartip' and getrightip = '$textendip'";
	}else{
		while($rows = $result->fetch()){
			$g_apps[] = $rows;
		}
		foreach ($g_apps as $key => $cuts){
			if($cuts['getleftip']  == $textstartip && $cuts['getrightip'] != $textendip){
				$addsql = "update {$dbPrefix}reip set getrightip = '$textendip' where getleftip = '$textstartip'";
				break;
			}else if($cuts['getleftip']  != $textstartip && $cuts['getrightip'] == $textendip){
				$addsql = "update {$dbPrefix}reip set getleftip = '$textstartip' where getrightip = '$textendip'";
				break;
			}else{
				$addsql = "insert into {$dbPrefix}reip(getleftip, getrightip) values ('$textstartip','$textendip')";
				break;
			}
		}
	}
	
	if($conn->query($addsql)){
		$response["sql"] = $addsql; 
		$response["result"] = 0; //成功
	}
}else{
	$response["result"] = 1;//为空
}


if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}

?>
