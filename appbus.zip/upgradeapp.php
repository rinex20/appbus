<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();
/* mysql_query("SET NAMES 'utf8'");
mysql_query("SET CHARACTER_SET_CLIENT=utf8");
mysql_query("SET CHARACTER_SET_RESULTS=utf8");  */
$conn->query('SET NAMES utf8'); 
$conn->query("SET CHARACTER_SET_CLIENT=utf8");
$conn->query("SET CHARACTER_SET_RESULTS=utf8");

//PackageName, AppName, Version, Version Code, APK File

$packagename = C_REQUEST("app_packagename");
$appname = C_REQUEST("app_appname");
$versionnumber = C_REQUEST("app_version");
$app_vercode = C_REQUEST("app_vercode");

$sql = "select * from {$dbPrefix}apps where appname = '$appname' and packagename = '$packagename' and versionnumber = '$versionnumber' and versioncode = '$app_vercode'";
//$result = mysql_query($sql, $conn);
$result = $conn->query($sql);
$sqlcount = "select COUNT(*) from {$dbPrefix}apps where appname = '$appname' and packagename = '$packagename' and versionnumber = '$versionnumber' and versioncode = '$app_vercode'";
//$num_rows = mysql_num_rows($result);
$num_rows = $conn->query($sql);
if ($num_rows == 0){
    $res["isexist"] = 0;

    $autoIncrementID = getTableAutoIncrementID($conn, "c_apps");

    if (!file_exists(UPLOAD_ABSPATH."/".$autoIncrementID)){
    	$flag = mkdir(UPLOAD_ABSPATH."/".$autoIncrementID, 0777);
        $res["mkdir."] = $flag;
    }

    $appapk = "";

    foreach($_FILES as $postname => $file_info){
        $res["file_info.name"][] = UPLOAD_ABSPATH."/".$autoIncrementID."/".$file_info["name"];
        $res["file_info.tmp_name"][] = $file_info["tmp_name"];
    	if(move_uploaded_file($file_info['tmp_name'], UPLOAD_ABSPATH."/".$autoIncrementID."/".$file_info["name"])){
        	$res["msg"] = "ok";
        	$appapk = $file_info["name"];
    	}else{
    	    $res["error"] = "error";
    	}		
    }


    $sql = "update {$dbPrefix}apps set packagename = '$packagename', appname = '$appname', versionnumber = '$versionnumber', ";
    $sql.= "versioncode = '$app_vercode', appapk = '$appapk' ";
    $sql.= "where appname = '$appname' and packagename = '$packagename' and versionnumber = '$versionnumber' and versioncode = '$app_vercode'";
    //echo $sql."<br>";
    $res["sql"] = $sql;
    //$result = mysql_query($sql, $conn);
	$result = $conn->query($sql);
    if ($result){
    $res["result"] = 0;
    } else {
    $res["result"] = 2;
    }
}
else {
    $res["isexist"] = 1;
}

echo json_encode($res);


?>