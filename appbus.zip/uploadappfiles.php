<?
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();
$conn->query('SET NAMES utf8'); 
$conn->query("SET CHARACTER_SET_CLIENT=utf8");
$conn->query("SET CHARACTER_SET_RESULTS=utf8");


$category = C_REQUEST("app_category", 1);
$packagename = C_REQUEST("app_packagename");
$appname = C_REQUEST("app_appname");
$versionnumber = C_REQUEST("app_version");
$app_vercode = C_REQUEST("app_vercode");
$description = C_REQUEST("app_description");
$app_start = C_REQUEST("app_start");
$app_forceinstall = C_REQUEST("app_forceinstall");
$app_icon = C_REQUEST("app_icon");
$app_device = C_REQUEST("app_device");
$upgradeapp = C_REQUEST("upgradeapp");
$sql = "select * from {$dbPrefix}apps where appname = '$appname' and packagename = '$packagename' and versionnumber = '$versionnumber' and versioncode = '$app_vercode'";
$res["sql_isexist"] = $sql;
$result = $conn->query($sql);
$sqlcount = "select COUNT(*) from {$dbPrefix}apps where appname = '$appname' and packagename = '$packagename' and versionnumber = '$versionnumber' and versioncode = '$app_vercode'";
$num_rows = $conn->query($sqlcount);
$num = $result->rowCount();
if ($num == 0){
    $res["isexist"] = 0;
    $autoIncrementID = getTableAutoIncrementID($conn, "{$dbPrefix}apps");
    if (!file_exists(UPLOAD_ABSPATH."/".$autoIncrementID)){
    	$flag = mkdir(UPLOAD_ABSPATH."/".$autoIncrementID, 0777);
        $res["mkdir."] = $flag;
    }
    $list_screenshots = array();
    $icon = "";
    $appapk = "";
    $res["error"] = "";

    foreach($_FILES as $postname => $file_info){
        if (empty($file_info["tmp_name"]))     continue;
        $res["file_info.name"][] = UPLOAD_ABSPATH."/".$autoIncrementID."/".$file_info["name"];
        $res["file_info.tmp_name"][] = $file_info["tmp_name"];
		$filesize=strlen($file_info["name"]);
		$filesize=$filesize-4;
		$file_info["name"]=substr_replace($file_info["name"],$packagename,0,$filesize);
        if(move_uploaded_file($file_info['tmp_name'], UPLOAD_ABSPATH."/".$autoIncrementID."/".$file_info["name"])){
            $res["msg"] = "ok";
			$res["Url1"] = UPLOAD_HTTP."/".$autoIncrementID."/".$file_info["name"];
			$icon = $file_info["name"].".png";
			$appapk = $file_info["name"];
        }else{
            $res["error"] = "error";
        }
    }
    $screenshots = implode(",", $list_screenshots);
	//将之前的icon复制到最新上传的文件夹里
	if($upgradeapp == 1){
		$query = "select * from {$dbPrefix}apps where packagename = '$packagename' and icon != ''";
		$rst = $conn->query($query);
		while($rs = $rst->fetch())
		{
			$t_apps[] = $rs;
		}
		foreach ($t_apps as $key => $tpps){
			$rs['icon'] = $tpps["icon"];
			$rs['id'] = $tpps["id"];
		}
		copy(UPLOAD_ABSPATH."/".$rs["id"]."/".$rs['icon'],UPLOAD_ABSPATH."/".$autoIncrementID."/".$rs['icon']);
		$icon = $rs["icon"];
		$res["copyicon1"] = UPLOAD_ABSPATH."/".$rs["id"]."/".$rs['icon'];
		$res["copyicon2"] = UPLOAD_ABSPATH."/".$autoIncrementID."/".$rs['icon'];
	}else{
		$res["copyicon1"] = UPLOAD_APK_PATH."/".preg_replace('/.*\//','',$app_icon);
		$res["copyicon2"] = UPLOAD_ABSPATH."/".$autoIncrementID."/".$file_info["name"].".png";
		copy($res["copyicon1"],UPLOAD_ABSPATH."/".$autoIncrementID."/".$file_info["name"].".png");
	}

    do {
        if ($res["error"] == "error")   break;
        $mask = "";
        $url1 = $appapk;
        $url2 = $appapk;
        $versiontime = curTime();
		$res["url1-url2"] =  $appapk;

		
		if($app_device == ""){
			$devicesql = "select device from {$dbPrefix}apps where packagename = '$packagename' and isoffshelf != '1' and id = (select max(id) from {$dbPrefix}apps where packagename = '$packagename' and isoffshelf != '1')";
				$result = $conn->query($devicesql);
				while($rows = $result->fetch())
				{
					$g_apps[] = $rows;
				}
				foreach ($g_apps as $key => $apps){
					$app_device = $apps["device"];
				}
				$res["device"] = $app_device;
		}
		

        $sql = "insert into {$dbPrefix}apps(id, packagename, appname, appapk, mask, icon, url1, url2, description, screenshots, ";
        $sql.= "category, versionnumber, versiontime, versioncode, forceinstall, start, device, isoffshelf) ";
        $sql.= "values('$autoIncrementID', '$packagename', '$appname', '$appapk', '$mask', '$icon', '$url1', '$url2', '$description', '$screenshots', ";
        $sql.= "'$category', '$versionnumber', '$versiontime', '$app_vercode', '$app_forceinstall', '$app_start' , '$app_device', '0')";
        $res["sql"] = $sql;
		$result = $conn->query($sql);
        if ($result){
			$sqlsetatus = "select setid from {$dbPrefix}setstatus where sets= '$app_device'";
			$sets = $conn->query($sqlsetatus);
			if($row = $sets->fetchColumn())
			{
				$sqlshort = "insert into {$dbPrefix}shortcut(id, setid, appid,type,value) values (null,'$row','$autoIncrementID','0','')";
				$conn->exec($sqlshort);   
				$res["result"] = 0;				
			}
        } else {
        $res["result"] = 2;
        }
    } while (0);

    
}else {
    $res["isexist"] = 1;
}

echo json_encode($res);


?>