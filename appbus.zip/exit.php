<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");
include("config/fg_config.php");

$conn = connectdb();

session_start();


updateUserSession($conn, $_SESSION[$fg_cfg["session"]["userid"]], $fg_cfg["session"]["defaulttime"]);

header ("Location: index.php");
	


?>