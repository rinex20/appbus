<?php require './templates/header.php';?>
	<div class="section">
		<div class="main">
			<pre class="pact" readonly="readonly"><?php echo $license;?></pre>
		</div>
	</div>
	<div class="btn-box">
		<a href="./index.php?step=0" class="btn">上一步</a>
		<a href="./index.php?step=2" class="btn">接 受</a>
	</div>
<?php require './templates/footer.php';?>