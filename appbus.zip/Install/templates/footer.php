		</div>
		<div class="footer"> <?php echo $config['footerInfo'];?> </div>
	</body>
</html>