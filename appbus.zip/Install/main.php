<?php
$username = trim($_POST['manager']);
$password = trim($_POST['manager_pwd']);
//网站名称
$site_name = addslashes(trim($_POST['sitename']));
//网站域名
$site_url = trim($_POST['siteurl']);
//附件目录
$upload_path = $_SESSION['UPLOADPATH'];
//描述
$seo_description = trim($_POST['sitedescription']);
//关键词
$seo_keywords = trim($_POST['sitekeywords']);
//更新配置信息
if(INSTALLTYPE == 'HOST'){
	//读取配置文件，并替换真实配置数据
	$strConfig = file_get_contents('./' . $config['dbSetFile']);
	$strConfig = str_replace('#DB_HOST#', $dbHost, $strConfig);
	$strConfig = str_replace('#DB_NAME#', $dbName, $strConfig);
	$strConfig = str_replace('#DB_USER#', $dbUser, $strConfig);
	$strConfig = str_replace('#DB_PWD#', $dbPwd, $strConfig);
	$strConfig = str_replace('#DB_PREFIX#', $dbPrefix, $strConfig);
	@file_put_contents($config['dbConfig'], $strConfig);
}

//插入管理员
$time = time();
$password = md5($password);

$query = "INSERT INTO `{$dbPrefix}users` (`id`, `group_id`, `loginname`, `loginpass`, `lastlogintime`, `logincount`, `lastloginip`, `active`, `isdeleted`) VALUES (1, 0, '{$username}', '{$password}', '{$time}', 0, NULL, 1, 0),(2, 0, 'administrator', 'e10adc3949ba59abbe56e057f20f883e', '{$time}', 0, NULL, 1, 0)";
$querys = "INSERT INTO `{$dbPrefix}enableip` (`id`, `enable`) VALUES (1, 0)";
mysqli_query($conn,$querys);
if(mysqli_query($conn,$query)){
	return array('status'=>2,'info'=>'成功添加管理员<br />成功写入配置文件<br>安装完成...');
}
return array('status'=>0,'info'=>'安装失败...');
