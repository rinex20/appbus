-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2020-03-14 14:26:16
-- 服务器版本： 5.6.47-log
-- PHP Version: 7.0.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `appbus`
--

-- --------------------------------------------------------

--
-- 表的结构 `apps_enableip`
--

CREATE TABLE IF NOT EXISTS `apps_enableip` (
  `id` int(11) NOT NULL,
  `enable` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 表的结构 `apps_reip`
--

CREATE TABLE IF NOT EXISTS `apps_reip` (
  `id` int(11) NOT NULL,
  `getleftip` varchar(15) NOT NULL,
  `getrightip` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 表的结构 `apps_setstatus`
--

CREATE TABLE IF NOT EXISTS `apps_setstatus` (
  `setid` int(11) NOT NULL,
  `sets` varchar(128) DEFAULT '',
  `status` varchar(128) DEFAULT NULL COMMENT 'ignore/delete',
  `starts` int(11) NOT NULL COMMENT '1：启动/0：不启动'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 表的结构 `apps_users`
--

CREATE TABLE IF NOT EXISTS `apps_users` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT '0' COMMENT '组ID，默认0',
  `loginname` varchar(128) NOT NULL COMMENT '登录名',
  `loginpass` varchar(128) NOT NULL COMMENT '登录密码',
  `lastlogintime` varchar(14) DEFAULT NULL COMMENT '最后登录时间',
  `logincount` int(11) NOT NULL DEFAULT '0' COMMENT '登录次数',
  `lastloginip` varchar(64) DEFAULT NULL COMMENT '最后登录ip',
  `active` int(11) NOT NULL DEFAULT '1' COMMENT '是否激活状态',
  `isdeleted` int(11) NOT NULL DEFAULT '0' COMMENT '1：已删除用户'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='前台用户表';

-- --------------------------------------------------------

--
-- 表的结构 `apps_usersession`
--

CREATE TABLE IF NOT EXISTS `apps_usersession` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `lastvisittime` varchar(14) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `c_apps`
--

CREATE TABLE IF NOT EXISTS `apps_apps` (
  `id` varchar(16) NOT NULL,
  `packagename` varchar(128) DEFAULT NULL,
  `appname` varchar(128) DEFAULT NULL,
  `appapk` varchar(64) DEFAULT NULL,
  `mask` varchar(128) DEFAULT NULL,
  `icon` varchar(256) DEFAULT NULL,
  `url1` varchar(256) DEFAULT NULL,
  `url2` varchar(256) DEFAULT NULL,
  `description` text,
  `screenshots` varchar(1024) DEFAULT NULL,
  `category` int(11) NOT NULL DEFAULT '1',
  `versionnumber` varchar(64) DEFAULT NULL,
  `versiontime` varchar(14) DEFAULT NULL,
  `versioncode` varchar(32) DEFAULT NULL,
  `forceinstall` int(11) NOT NULL DEFAULT '0' COMMENT '1:true; 0:false',
  `start` int(11) NOT NULL COMMENT '快速启动1:启动',
  `device` varchar(128) DEFAULT NULL,
  `isoffshelf` int(11) NOT NULL DEFAULT '0' COMMENT '1:已下架'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `shortcut`
--

CREATE TABLE IF NOT EXISTS `apps_shortcut` (
  `id` int(11) NOT NULL,
  `setid` int(11) DEFAULT NULL,
  `appid` varchar(16) CHARACTER SET utf8 DEFAULT NULL,
  `type` int(2) DEFAULT '0' COMMENT '类型（1:model，2:sequence，3:ip）',
  `value` varchar(265) DEFAULT NULL COMMENT '参数（字符串|数组）'
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apps_enableip`
--
ALTER TABLE `apps_enableip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apps_reip`
--
ALTER TABLE `apps_reip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apps_setstatus`
--
ALTER TABLE `apps_setstatus`
  ADD PRIMARY KEY (`setid`);

--
-- Indexes for table `apps_users`
--
ALTER TABLE `apps_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apps_usersession`
--
ALTER TABLE `apps_usersession`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `c_apps`
--
ALTER TABLE `apps_apps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `shortcut`
--
ALTER TABLE `apps_shortcut`
  ADD PRIMARY KEY (`id`),
  ADD KEY `setid` (`setid`),
  ADD KEY `short_apps` (`appid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apps_reip`
--
ALTER TABLE `apps_reip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `apps_setstatus`
--
ALTER TABLE `apps_setstatus`
  MODIFY `setid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `apps_users`
--
ALTER TABLE `apps_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `apps_usersession`
--
ALTER TABLE `apps_usersession`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `shortcut`
--
ALTER TABLE `apps_shortcut`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=102;
--
-- 限制导出的表
--

--
-- 限制表 `shortcut`
--
ALTER TABLE `apps_shortcut`
  ADD CONSTRAINT `short_apps` FOREIGN KEY (`appid`) REFERENCES `apps_apps` (`id`),
  ADD CONSTRAINT `short_set_1` FOREIGN KEY (`setid`) REFERENCES `apps_setstatus` (`setid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
