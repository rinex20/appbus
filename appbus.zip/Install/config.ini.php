<?php
define('DB_DBMS', 'mysql');
define('DB_NAME', '#DB_NAME#');
define('DB_USER', '#DB_USER#');
define('DB_PASSWORD', '#DB_PWD#');
define('DB_HOST', '#DB_HOST#');
define('DB_PREFIX', '#DB_PREFIX#');
define('DB_DSN', 'mysql:host=#DB_HOST#;dbname=#DB_NAME#');
$dbPrefix = '#DB_PREFIX#';

define('ROOT_DIV', dirname(dirname(__FILE__)));
define('ROOT_HTDOCS', 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"]);
define('UPLOAD_HTTP', 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/upload');
define('UPLOAD_APK_HTTP', 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/upload/apkinfo');
define('UPLOAD_ABSPATH', ROOT_DIV.'/upload');
define('UPLOAD_APK_PATH', ROOT_DIV.'/upload/apkinfo');

$common_cfg["upload_folder"]["appfiles"] = "/appfiles/";
$common_cfg["upload_folder"]["appshotscreen"] = "/appshotscreen/";
?>