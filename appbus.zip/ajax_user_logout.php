<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");
include("config/fg_config.php");

$conn = connectdb();
session_start();
unset($_SESSION['appmanage_user_userid']);
$jsoncallback = C_GET("jsoncallback");

header('Content-Type: text/html; charset=utf-8');
$_SESSION['appmanage_user_userid']=null;

updateUserSession($conn, $_SESSION[$fg_cfg["session"]["userid"]], $fg_cfg["session"]["defaulttime"]);
$response["result"] = 0;
	
if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}
?>