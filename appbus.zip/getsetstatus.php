<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();
/* mysql_query("SET NAMES 'utf8'");
mysql_query("SET CHARACTER_SET_CLIENT=utf8");
mysql_query("SET CHARACTER_SET_RESULTS=utf8");  */
$conn->query('SET NAMES utf8'); 
$conn->query("SET CHARACTER_SET_CLIENT=utf8");
$conn->query("SET CHARACTER_SET_RESULTS=utf8");

$jsoncallback = C_GET("jsoncallback");
$type = C_GET("type");

header('Content-Type: text/html; charset=utf-8');

$g_packagenames = array();
$g_apps = array();
$sql = "select * from {$dbPrefix}setstatus where sets = '$type'";
$response["sql"] = $sql;
//$result = mysql_query($sql, $conn);
$result = $conn->query($sql);
if ($result){   
	foreach ($conn->query($sql) as $row) {
		$res = $row;
	}
	if($rows = $result->fetch()){
		$response["result"] = 0;
        $response["IfNotInList"] = $rows["status"];
	}else{
		$response["result"] = 2;
		$response["IfNotInList"] = "ignore";
	}
    /* if ($rows = mysql_fetch_array($result))
    {
        $response["result"] = 0;
        $response["IfNotInList"] = $rows["status"];
    }
    else{
        $response["result"] = 2;
		$response["IfNotInList"] = "ignore";
    } */
}
else{
    $response["result"] = 1;
	$response["IfNotInList"] = "ignore";
}

if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}

?>