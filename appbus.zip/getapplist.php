<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();
$conn->query('SET NAMES utf8'); 
$conn->query("SET CHARACTER_SET_CLIENT=utf8");
$conn->query("SET CHARACTER_SET_RESULTS=utf8");
$jsoncallback = C_GET("jsoncallback");
$type = C_GET("type");
header("Access-Control-Allow-Origin", "*");
function getPackageNameIdx($packagename, $list){
    //echo $packagename."<br>\n";
    $idx = -1;
    foreach ($list as $i => $value) {
        //echo $value."<br>\n";
        if ($value == $packagename){
            $idx = $i;
            break;
        }
    }
    return $idx;
}


$ip_apps = array();
$iparray = array();
$sqlselect = "select * from {$dbPrefix}reip";
$ipresult = $conn->query($sqlselect);
while($iprows = $ipresult->fetch())
{
	$ip_apps[] = $iprows;
}
foreach ($ip_apps as $key => $apps){
	unset($_s);
	$_s["0"] = $apps["getleftip"];
	$_s["1"] = $apps["getrightip"];
	$iparray[] = $_s;
}

$getcip = get_real_ip();
$is_or_no = is_ip($getcip,$iparray);

header('Content-Type: text/html; charset=utf-8');
$devicesetss = C_REQUEST("devicesetss");
if($devicesetss == ""){
	$devicesetss = "全部";
}
$str2="'";
if($devicesetss == "全部"){
	$devicesetss = "apps_setstatus.sets";
}else if(strstr($devicesetss,$str2)){
	$devicesetss= "'".$devicesetss."'";
}else if($devicesetss == "apps_setstatus.sets"){
	$devicesetss == "apps_setstatus.sets";
}else{
	//$devicesetss = "apps_setstatus.sets";
	$devicesetss= "'".$devicesetss."'";
}

$setenableip = "";
$sqlip = "select * from {$dbPrefix}enableip";
$result = $conn->query($sqlip);
while($rows = $result->fetch())
{
	$g_apps[] = $rows;
}
foreach ($g_apps as $key => $apps){
	if($apps["enable"] == "1"){
		$setenableip = false;
	}else{
		$setenableip = true;
	}
}

$g_packagenames = array();
$g_apps = array();
$sql = "select * from {$dbPrefix}shortcut,{$dbPrefix}setstatus,{$dbPrefix}apps where {$dbPrefix}shortcut.setid = {$dbPrefix}setstatus.setid and {$dbPrefix}shortcut.appid = {$dbPrefix}apps.id and {$dbPrefix}apps.isoffshelf = 0 and {$dbPrefix}apps.device = $devicesetss order by {$dbPrefix}apps.id desc";
$result = $conn->query($sql);
while($rows = $result->fetch())
{
	if ($rows["packagename"] == "")   continue;
	$g_apps[] = $rows;
}
$response = array();
if($is_or_no || $setenableip){
foreach ($g_apps as $key => $apps){
    unset($_t);
	
    $_t["id"] = $apps["id"];
    $_t["PackageName"] = $apps["packagename"];
    $_t["AppName"] = $apps["appname"];

    $_t["ForceInstall"] = ($apps["forceinstall"]==1)?"true":"false";
    $_t["device"] = $apps["device"];
    if ($apps["icon"] == "")
        $_t["Icon"] = $apps["icon"];
    else
        $_t["Icon"] = UPLOAD_HTTP."/".$apps["id"]."/".$apps["icon"];	

    $_t["Mask"] = $apps["mask"];    
	
    if ($apps["url1"] != "" ){
	$packname=$apps["packagename"].".apk";
	$packagename=$apps["packagename"];
		if( $apps["url1"] != $packname){
		$httpname = UPLOAD_ABSPATH."/".$apps["id"]."/".$apps["url1"];
		$httppack   = UPLOAD_ABSPATH."/".$apps["id"]."/".$packname;
		rename($httpname,$httppack);
		$upsql="update {$dbPrefix}apps set url1 = '$packname' where packagename='$packagename'";
		$resultup = $conn->exec($upsql);
	}
//	if( $apps["url1"] != $packname){
//		$httpname = UPLOAD_ABSPATH."/".$apps["id"]."/".$apps["appapk"];
//		$httppack   = UPLOAD_ABSPATH."/".$apps["id"]."/".$packname;
//		rename($httpname,$httppack);
//		$upsql="update c_apps set url1 = '$packname' where packagename='$packagename'";
//		$resultup = mysql_query($upsql, $conn);
//	}
	$_t["Url1"] = UPLOAD_HTTP."/".$apps["id"]."/".$apps["url1"];
	}else{
		$_t["Url1"] = $apps["url1"];
	}
	
    $_t["Url2"] = $apps["url2"];
    $_t["description"] = $apps["description"];    
    $_t["category"] = $apps["category"];

    unset($screenshots);
    $_t["shot"] = array();
    $list_shot = explode(",", $apps["screenshots"]);


    //每个version作为一条记录保存在version节点下
    unset($version);
    $_t["Version"] = array();
    $_t["Details"] = array();
    $details['type'] = $apps['type'];
    $details['value'] = $apps['value'];
    if($details['value'] && json_decode($details['value'])){
    	$details['value'] = json_decode($details['value'], true);
    }
    
    //if($apps['value']){
    //	
    //}
    $_t["Details"] = $details;
    $version["Ver"] = $apps["versionnumber"];
	$version["Time"] = showdate($apps["versiontime"], $format="yyyymmddhhiiss", $yf="-", $mf="-", $df=" ", $hf=":", $if=":", $sf="");
    $version["Code"] = $apps["versioncode"];
	$version["Desc"]  = $apps["description"];
    $i_packageNames = getPackageNameIdx($apps["packagename"], $g_packagenames);
    if ($i_packageNames == -1){
        foreach ($list_shot as $i => $shot) {
            if ($shot == "")    continue;

            $screenshots["id"] = $i;
            $screenshots["path"] = UPLOAD_HTTP."/".$apps["id"]."/".$shot;
            
            $_t["shot"][] = $screenshots;
        }
        //record last version
        $_t["Ver"] = $apps["versionnumber"];
        $_t["Time"] = $apps["versiontime"];
        $_t["Code"] = $apps["versioncode"];
		$_t["Desc"]  = $apps["description"];
        //record last version

        $_t["Version"][] = $version;
        $response[] = $_t;

        $g_packagenames[] = $apps["packagename"];
    }else {
        foreach ($list_shot as $i => $shot) {
            if ($shot == "")    continue;

            $screenshots["id"] = count($response[$i_packageNames]["shot"]);
            $screenshots["path"] = UPLOAD_HTTP."/".$apps["id"]."/".$shot;
            
            $response[$i_packageNames]["shot"][] = $screenshots;
        }

        $response[$i_packageNames]["Version"][] = $version;
    }


    
}
}

if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}


?>