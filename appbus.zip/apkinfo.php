<?php
class Service_Android
{
	
    /**
    * 获取Apk包信息
    *
    * 需要/usr/bin/aapt
    *
    * @param $apkFile
    * @return array
    */
    public function getApkInfo($apkFile)
    {
    	
        try {
		exec('aapt dump badging ' . $apkFile, $out, $return);
        $apkInfo = array();
        foreach ($out as $line) {
        $lineana = array();
        $a = explode(":", $line);
        $key = trim($a[0]);
        $value = trim($a[1]);
        preg_match_all('/((?P<key>\S+)=)?\'(?P<value>.*?)\'/', $value, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
        if ($match['key']) {
        $lineana[$match['key']] = $match['value'];
        } else {
        $lineana[] = $match['value'];
        }
        }
        $apkInfo[$key][] = $lineana;
        }
        //checkRet会把上面读出来的配置整理一下
        $ret = $this->checkRet($apkInfo);
        } catch (Exception $e) {
        echo $e->getMessage();
        $ret = array();
        }
        return $ret;
    }
     
    /**
    * 从Apk包中提取指定文件,并移到$toFile
    *
    * @param $apkFile apk文件
    * @param $sourceFile apk文件中相应文件路径
    * @param $toFile 输出文件
    * @return bool
    */
    function getFileFromApk($apkFile, $sourceFile, $toFile)
	{
	$dir = dirname(__FILE__);
	exec('unzip ' . $apkFile .' '.$sourceFile.' -d '.$dir.'/tmp', $out, $return);
	if (rename($dir."/tmp/" . $sourceFile, $toFile)) {
	//exec('unzip ' . $apkFile .' '.$sourceFile.' -d /www/wwwroot/appbus.168fapai.com/tmp', $out, $return);
	//if (rename("/www/wwwroot/appbus.168fapai.com/tmp/" . $sourceFile, $toFile)) {
	return true;
	} else {
	return false;
	}
	}
         
        /**
        * 辅助函数,处理Apk信息数组
        *
        * @param $info
        * @return mixed
        */
    function checkRet($info)
    {
        foreach ($info as $key => $lineana) {
        if (is_array($lineana)) {
        $info[$key] = $this->checkRet($lineana);
        if (count($info[$key]) == 1) {
        $info[$key] = current($info[$key]);
        }
        } else {
        }
        }
        return $info;
    }
	
	
	
	public function apkParseInfo($apk) 
	{  
		$dir = dirname(__FILE__);
        $aapt = 'aapt';// 这里其实是aapt的路径，不过我已经ln到/usr/local/aapt了。就不用了。  
        $temp_save_path= $dir+'/upload/apkinfo/';  
  
        exec("{$aapt} d badging {$apk}", $output, $return);  
  
        // 解析错误  
        if ( $return !== 0 ) {  
            return FALSE;  
        }  
  
        $output = implode(PHP_EOL, $output);  
  
  
        var_dump($output);  
		
		var_dump($return);
  
        echo '<br/>';  
  
        $apkinfo = new \stdClass;  
  
        // 对外显示名称  
        $pattern = "/application: label='(.*)'/isU";  
        $results = preg_match($pattern, $output, $res);  
        $apkinfo->label = $results ? $res[1] : '';  
  
        // 内部名称，软件唯一的  
        $pattern = "/package: name='(.*)'/isU";  
        $results = preg_match($pattern, $output, $res);  
        $apkinfo->sys_name = $results ? $res[1] : '';  
  
        // 内部版本名称，用于检查升级  
        $pattern = "/versionCode='(.*)'/isU";  
        $results = preg_match($pattern, $output, $res);  
        $apkinfo->version_code = $results ? $res[1] : 0;  
  
        // 对外显示的版本名称  
        $pattern = "/versionName='(.*)'/isU";  
        $results = preg_match($pattern, $output, $res);  
        $apkinfo->version = $results ? $res[1] : '';  
  
        // 系统支持  
        $pattern = "/sdkVersion:'(.*)'/isU";  
        $results = preg_match($pattern, $output, $res);  
        $apkinfo->sdk_version = $results ? $res[1] : 0;  
  
        // 分辨率支持  
        $densities = array(  
            "/densities: '(.*)'/isU",  
            "/densities: '120' '(.*)'/isU",  
            "/densities: '160' '(.*)'/isU",  
            "/densities: '240' '(.*)'/isU",  
            "/densities: '120' '160' '(.*)'/isU",  
            "/densities: '160' '240' '(.*)'/isU",  
            "/densities: '120' '160' '240' '(.*)'/isU"  
        );  
  
        foreach($densities AS $k=>$v) {  
            if( preg_match($v, $output, $res) ) {  
                $apkinfo->densities[] = $res[1];  
            }  
        }  
  
        // 应用权限  
        $pattern = "/uses-permission: name='(.*)'/isU";  
        $results = preg_match_all($pattern, $output, $res);  
        $apkinfo->permissions = $results ? $res[1] : '';  
  
        // 需要的功能（硬件支持）  
        $pattern = "/uses-feature: name='(.*)'/isU";  
        $results = preg_match_all($pattern, $output, $res);  
        $apkinfo->features = $results ? $res[1] : '';  
  
        // 应用图标路径  
        if( preg_match("/icon='(.+)'/isU", $output, $res) ) {  
  
            $icon_draw = trim( $res[1] );  
            $icon_hdpi = 'res/drawable-hdpi/' . basename($icon_draw);  
  
            $temp =$temp_save_path.basename($apk, '.apk') . DIRECTORY_SEPARATOR;  
  
            if( @is_dir($temp) === FALSE ) {  
                mkdir($temp,0777,true);  
            }  
  
            exec("unzip {$apk} {$icon_draw} -d " . $temp);  
            exec("unzip {$apk} {$icon_hdpi} -d " . $temp);  
  
            $apkinfo->icon = $icon_draw;  
  
            $icon_draw_abs = $temp . $icon_draw;  
            $icon_hdpi_abs = $temp . $icon_hdpi;  
  
            $apkinfo->icon = @is_file($icon_hdpi_abs) ? $icon_hdpi_abs : $icon_draw_abs;  
        }  
  
        return $apkinfo;  
    } 
}
?>