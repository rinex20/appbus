<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();

include("config/fg_config.php");


session_start();

$jsoncallback = C_GET("jsoncallback");

header('Content-Type: text/html; charset=utf-8');

$inModel = C_REQUEST("inModel");
$response["inModel"] = $inModel;

$sql = "select * from {$dbPrefix}setstatus WHERE sets = '$inModel'";
//$result = mysql_query($sql, $conn);
$result = $conn->query($sql);
$response["sql"] = $sql;

if ($result){
	$response["result"] = 1;
}else{
	$addsql = "INSERT INTO {$dbPrefix}setstatus('setid', 'sets', 'status', 'starts') VALUES ('','$inModel','ignore','1')";
	if($conn->query($sql))
		$response["result"] = 0;
	$response["result"] = 2;
}


if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
} 

?>
