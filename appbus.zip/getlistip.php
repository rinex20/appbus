<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();
/* mysql_query("SET NAMES 'utf8'");
mysql_query("SET CHARACTER_SET_CLIENT=utf8");
mysql_query("SET CHARACTER_SET_RESULTS=utf8");  */
$conn->query('SET NAMES utf8'); 
$conn->query("SET CHARACTER_SET_CLIENT=utf8");
$conn->query("SET CHARACTER_SET_RESULTS=utf8");
$jsoncallback = C_GET("jsoncallback");
$type = C_GET("type");
function getPackageNameIdx($packagename, $list){
    //echo $packagename."<br>\n";
    $idx = -1;
    foreach ($list as $i => $value) {
        //echo $value."<br>\n";
        if ($value == $packagename){
            $idx = $i;
            break;
        }
    }
    return $idx;
}
header('Content-Type: text/html; charset=utf-8');
$g_apps = array();
$sql = "select * from {$dbPrefix}reip";
$result = $conn->query($sql);
while($rows = $result->fetch())
{
	$g_apps[] = $rows;
}
$response = array();
foreach ($g_apps as $key => $apps){
    unset($_t);
    $_t["id"] = $apps["id"];
    $_t["startip"] = $apps["getleftip"];
    $_t["endip"] = $apps["getrightip"];
	$response[] = $_t;
}
if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}


?>