<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();

include("config/fg_config.php");


session_start();

$jsoncallback = C_GET("jsoncallback");

header('Content-Type: text/html; charset=utf-8');



$packagename = C_REQUEST('packagename');
$response["packagename"] = $packagename;


$new_packagename = "OFFSHELF_".$packagename;
$sql = "update {$dbPrefix}apps set packagename = '$new_packagename', isoffshelf = 1 where packagename = '$packagename'";
//$result = mysql_query($sql, $conn);
$result = $conn->query($sql);
$response["sql"] = $sql;

if ($result)
    $response["result"] = 0;
else
    $response["result"] = 1;


if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
} 

?>
