<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");
$conn = connectdb();
include("config/fg_config.php");
session_start();
$jsoncallback = C_GET("jsoncallback");

header('Content-Type: text/html; charset=utf-8');

$loginname = C_REQUEST('loginname');
$loginpass = C_REQUEST('loginpass');
$xgpassword= md5("123456");
$t_login = UpdateInitialize($conn, $loginname, md5($loginpass),$xgpassword);
$response["result"] = 0;




if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}
?>
