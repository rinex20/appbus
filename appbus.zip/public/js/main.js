Date.prototype.pattern=function(fmt) {        
    var o = {        
    "M+" : this.getMonth()+1, //月份        
    "d+" : this.getDate(), //日        
    "h+" : this.getHours()%12 == 0 ? 12 : this.getHours()%12, //小时        
    "H+" : this.getHours(), //小时        
    "m+" : this.getMinutes(), //分        
    "s+" : this.getSeconds(), //秒        
    "q+" : Math.floor((this.getMonth()+3)/3), //季度        
    "S" : this.getMilliseconds() //毫秒        
    };        
    var week = {        
    "0" : "\u65e5",        
    "1" : "\u4e00",        
    "2" : "\u4e8c",        
    "3" : "\u4e09",        
    "4" : "\u56db",        
    "5" : "\u4e94",        
    "6" : "\u516d"       
    };        
    if(/(y+)/.test(fmt)){        
        fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));        
    }        
    if(/(E+)/.test(fmt)){        
        fmt=fmt.replace(RegExp.$1, ((RegExp.$1.length>1) ? (RegExp.$1.length>2 ? "\u661f\u671f" : "\u5468") : "")+week[this.getDay()+""]);        
    }        
    for(var k in o){        
        if(new RegExp("("+ k +")").test(fmt)){        
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));        
        }        
    }        
    return fmt;        
}

$('#btn_test').click(function() {

});


var g_sessionid = "";
function UserLogin(loginname, loginpass, cbSucc, cbFail){
    console.log(loginname + ", " + loginpass);
    $.ajax( {
        url: "ajax_user_login.php",
        data: {"loginname":loginname, "loginpass":loginpass},
        type: 'get',
        dataType: 'jsonp',
        jsonp: "jsoncallback",
        success: function(data, status){
            console.log(data);
            if (data.result == 0){
                g_sessionid = data.sessionid;
            }
            else if (data.result == 1){
                //用户名错误
            }
            else if (data.result == 2){
                //密码错误
            }
        },
        error: function(data, status){
            console.log(data);
        },
    }); 
}

function saveSetModel() {
        var inModel = $("#inModel").val();
        $.ajax( {
            url: "ajax_user_setmodel.php",
            data: {"inModel":inModel},
            type: 'get',
            dataType: 'jsonp',
            jsonp: "jsoncallback",
            success: function(data, status){
				console.log(data);
				console.log(status);
                if (data.result == 0){  
                	alert("添加成功");
                	document.getElementById("inModel").value="";
                	$('#btn_setmodel_close').click();
                }
                else if (data.result == 1){
                	alert("添加失败，已有该设备名");
                	console.log(data.result);
                }
                else if (data.result == 2){
                	alert("添加失败，设备名不能为空");
                	console.log(data.result);
                }
            },
            error: function(data, status){
                console.log(data);
            },
        }); 
    }

function xgpass() {
        var xgpassword = $("#xgpassword").val();
        var xgpassword2 = $("#xgpassword2").val();
        $.ajax( {
            url: "ajax_user_xgpass.php",
            data: {"xgpassword":xgpassword,"xgpassword2":xgpassword2},
            type: 'get',
            dataType: 'jsonp',
            jsonp: "jsoncallback",
            success: function(data, status){
                if (data.result == 0){  
                	alert("修改成功");
                	$('#btn_setpass_close').click();
                	document.getElementById("xgpassword").value="";
                }
                else if (data.result == 1){
                	alert("修改失败，密码不能为空");
                	console.log(data.result);
                }
                else if (data.result == 2){
                	alert("修改失败，密码不一致");
                	console.log(data.result);
                }
            },
            error: function(data, status){
                console.log(data);
            },
        }); 
}
	

function saveip() {
    var textstartip = $("#textstartip").val();
    var textendip = $("#textendip").val();
    $.ajax( {
        url: "ajax_user_ip.php",
        data: {"textstartip":textstartip,"textendip":textendip},
        type: 'get',
        dataType: 'jsonp',
        jsonp: "jsoncallback",
        success: function(data, status){
			console.log(data);
            if (data.result == 0){  
            	alert("成功");
            	document.getElementById("textstartip").value="";
				document.getElementById("textendip").value="";
				history.go(0);
			}else{
            	alert("失败,不能为空");
            	console.log(data.result);
            }

        },
        error: function(data, status){
            console.log(data);
        },
    }); 
}

function saveSetInstallModel() {
    var type = $("#itemtypeselect").val();
    var id = $("#app_appid").val();
	var value = new Array();
    $('#itemvalue input').each(function(){
    	value.push($(this).val());//添加至数组
	});
    $.ajax( {
        url: "ajax_install_model.php",
        data: {"id":id,"type":type,"value":value},
        type: 'get',
        dataType: 'jsonp',
        jsonp: "jsoncallback",
        success: function(data, status){
			console.log(data);
            if (data.result == 1){  
            	alert("成功");
			}else{
            	alert("失败");
            }

        },
        error: function(data, status){
            console.log(data);
        },
    }); 
}


function Initialize() {
	    var xgpassword = "";
        var xgpassword2 = "";
        $.ajax( {
            url: "ajax_user_inz.php",
            data: {"xgpassword":xgpassword,"xgpassword2":xgpassword2},
            type: 'get',
            dataType: 'jsonp',
            jsonp: "jsoncallback",
            success: function(data, status){
                if (data.result == 0){  
                	alert("初始化成功");
                	$('#btn_setpass_close').click();
                }
                else if (data.result == 1){
                	alert("初始化失败");
                	console.log(data.result);
                }
                else if (data.result == 2){
                	alert("初始化失败");
                	console.log(data.result);
                }
            },
            error: function(data, status){
                console.log(data);
            },
        }); 
    }


function UserLogout(cbSucc, cbFail){
    console.log(g_sessionid);
    $.ajax( {
        url: "ajax_user_logout.php",
        data: {},
        type: 'get',
        dataType: 'jsonp',
        jsonp: "jsoncallback",
        success: function(data, status){
            console.log(data);
            
        },
        error: function(data, status){
            console.log(data);
        },
    }); 
}



function saveSetStatus() {
		var devicetype =  $("#devicetype").find("option:selected").text();
        var ifnotinlist = $("#ifnotinlist").val();
        var starts_check = ($("#starts_checkbox_forceinstall").prop("checked")==true) ? 1 : 0;
        console.log(devicetype + ", " + ifnotinlist + "," +starts_check);
        $.ajax( {
            url: "ajax_setsetstatus.php",
            data: {"devicetype":devicetype, "ifnotinlist":ifnotinlist,"starts_check":starts_check},
            type: 'get',
            dataType: 'jsonp',
            jsonp: "jsoncallback",
            success: function(data, status){
           //     console.log(data);
                if (data.result == 0){
                    console.log(data.result);
                    $('#btn_setstatus_close').click();
//                        if(starts_check)
//					        $("#starts_checkbox_forceinstall").prop("checked")==true
//					      else
//					        $("#starts_checkbox_forceinstall").prop("checked")==false
                }
                else if (data.result == 1){
                    //database error
                }
            },
            error: function(data, status){
                console.log(data);
            },
        }); 
    };
/*start upload*/

$(document).ready(function(){    

});

/*end upload*/

