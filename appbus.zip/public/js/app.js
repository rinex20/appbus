'use strict';
var allApps = [];
var allip = [];
var curListApps = allApps;
var pagenum = 0;
var curDeviceType = "apps_setstatus.sets";
var shortcut;
var protocol = window.location.protocol;
var host = window.location.host;
var roothttpaddress = protocol+"//"+host+"/app/";
console.log(roothttpaddress);
Date.prototype.Format = function(fmt)   
{
	var o = {   
		"M+" : this.getMonth()+1,                 //月份   
		"d+" : this.getDate(),                    //日   
		"h+" : this.getHours(),                   //小时   
		"m+" : this.getMinutes(),                 //分   
		"s+" : this.getSeconds(),                 //秒   
		"q+" : Math.floor((this.getMonth()+3)/3), //季度   
		"S"  : this.getMilliseconds()             //毫秒   
	};   
	if(/(y+)/.test(fmt))   
		fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));   
	for(var k in o)   
	if(new RegExp("("+ k +")").test(fmt))   
		fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));   
	return fmt;   
}
angular.module('AppStoreDemo.MainController', ['ngRoute'])
.config(['$routeProvider', function($routeProvider) {
	$routeProvider.when('/', {
		templateUrl: 'main.html',
		controller: 'AppStoreMainController'
	});
}])
.controller('AppStoreMainController', ['$scope','$http','LoginData',function($scope,$http,LoginData) {
	$http.get('app/ajax_user.php').success(function(data){
		if(data['appmanage_user_username'] == "admin")
		{
			g_sessionid = data.sessionid;
			$scope.loginstate = 1;
			$scope.loginstate1 = 1;
			$scope.loginstate0 = 1;
			$scope.username = data.appmanage_user_username;
			LoginData.state = 1;
			LoginData.name = $scope.username;
	
		}else if(data['appmanage_user_username'] == "administrator"){
			g_sessionid = data.sessionid;
			$scope.loginstate0 = 1;
			$scope.loginadminstate= 1;
			$scope.username = data.appmanage_user_username;
			LoginData.state = 1;
			LoginData.name = $scope.username;
		}else{
			window.location.href = 'login.php';
		}
	});
	$scope.setCategory = function(i)
	{
		$scope.selectedcategory = i;
	};
	$scope.maininit = function()
	{
		$scope.loginstate = LoginData.state;
		$scope.username = LoginData.name;
		$scope.appcategorys = appCategorys;
		$scope.selectedcategory = 1;
		$scope.curCategory = appCategorys[0];
		
		$http({
			//url:roothttpaddress+'getapplist.php',  
			url:'/app/getapplist.php',  
			method: 'get',    
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			params: { devicesetss: 'apps_setstatus.sets' }//作为消息体参数    
			}).success(function(data){
				$scope.applist={sets : "apps_setstatus.sets",device : "全部",setid:1};
				allApps = data;
				var abb ={};
				$scope.allapps = allApps;
				$scope.alldata = $scope.allapps;
				abb = $scope.alldata.concat($scope.applist);
				abb.reverse();
				$scope.alldata = abb;
				for(var i in $scope.alldata){
					if($scope.alldata[i].setid==1){//将id是1的设为选中项.
						$scope.appsDevice=$scope.alldata[i];
						break;
					}
				}
			}).error(function(data){  
				console.log("error");  
			});
		$http.get('/app/getsetsites.php').success(function(data){
		//$http.get(roothttpaddress+'getsetsites.php').success(function(data){
			console.log(data);  
			$scope.sites=[];
			for(var o in data){
			shortcut=data[o];
				$scope.sites.push(shortcut);
			}
		});
		
		$http.get(roothttpaddress+'getdevice.php').success(function(data){
			console.log("getdevice:"+data);  
			$scope.getdevice= data;
		});
	
		$http.get(roothttpaddress+'getenableip.php').success(function(data){
			console.log(data);  
			$scope.getenableip = data;
			if($scope.getenableip.enable == true)
				$scope.getenableip.enable = true;
			else
				$scope.getenableip.enable = false;
		});
	
	
		$http.get(roothttpaddress+'getlistip.php').success(function(data){
			console.log("getlistip:"+data);  
			allip = data;
			$scope.allip = allip;
		}).error(function(data){  
			console.log("error");  
		});
		
	};
	$scope.appsupdate = function()
	{    
		console.log($scope.appsDevice.device);
		$.ajax( {
			url: "app/getapplist.php",
			data: {"devicesetss": $scope.appsDevice.device},
			type: 'get',
			dataType: 'jsonp',
			jsonp: "jsoncallback",
			success: function(data){
				$scope.allapps = data;
				$scope.$apply();
				console.log(data);
			},
			error: function(data){
				console.log(data);
			},
		}); 
	}
  
	$scope.selectedupdate = function()
	{    
		var devicetype =  $("#devicetype").find("option:selected").text();
		$.ajax( {
			url: "app/getstarts.php",
			data: {"devicetype": devicetype},
			type: 'get',
			dataType: 'jsonp',
			jsonp: "jsoncallback",
			success: function(data){
			console.log(data);
				for(var o in data){
					if(devicetype == data[o].sets && data[o].starts == 1){
							$scope.sites.starts = true;
						}else{
							$scope.sites.starts = false;
						}
				}
				$scope.$apply();
				var imglist=$("#kuaijie img");//获取ID为div里面的所有img
				if (imglist.length < 2)
				{
					document.getElementById('kuaijiestatus').innerHTML="";
				}else{
					document.getElementById('kuaijiestatus').innerHTML="...";
				}
				
			},
			error: function(data){
				console.log(data);
				$scope.sites.starts = false;
			},
		}); 
	}
  
	$scope.selectCategory = function()
	{
		console.log("curCategory = "+$scope.curCategory.type);
	};
	$scope.login = function()
	{
		console.log("login");
		$.ajax( {
			url: "app/ajax_user_login.php",
			data: {"loginname":$scope.username, "loginpass":$scope.password},
			type: 'get',
			dataType: 'jsonp',
			jsonp: "jsonpCallback",
			success: function(data, status){
				console.log(status);
				if (data.result == 0){
					g_sessionid = data.sessionid;
					$scope.loginstate = 1;
					$scope.$apply();
					LoginData.state = 1;
					LoginData.name = $scope.username;
					LoginData.pwd = $scope.password;
				}
				else if (data.result == 1){
					alert("用户名错误");
				}
				else if (data.result == 2){
					alert("密码错误");
				}
				else if (data.result == 3){
					g_sessionid = data.sessionid;
					$scope.loginstate1 = 0;
					$scope.loginadminstate = 1;
					$scope.$apply();
					LoginData.state = 1;
					LoginData.name = $scope.username;
					LoginData.pwd = $scope.password;
					window.location.href = 'index.php';
				}
			},
			error: function(data, status){
				//console.log(status);
				console.log(data);
			},
		}); 
	}
  
	$scope.fileChanged = function(ele){
		$("#uploadTip").modal('show');
		/***
         * ajaxFileUpload
         * 关于在Chrome使用ajaxFileUpload上传时。如果多次上传。会出现file中没有文件信息，经查明ajaxFileUpload源码中没有保留原file的文件信息
         * 修改：
		 * createUploadForm 方法中增加newElement[0].files=oldElement[0].files; 
         * 2017-12-27
         * /
         **/
		$.ajaxFileUpload
		(
			{
				url: 'app/apkfiles.php', //用于文件上传的服务器端请求地址
				secureuri: false, //一般设置为false
				fileElementId: 'app_apk', //文件上传空间的id属性  <input type="file" id="file" name="file" />
				dataType: 'json', //返回值类型 一般设置为json
				success: function (data, status)  //服务器成功响应处理函数
				{
				  console.log(data);
				  $("#uploadTip").modal('hide');
				  $scope.app_packagename = data["packageName"];
				  $scope.app_appname = data["appName"];
				  $scope.app_version = data["versionName"];
				  $scope.app_vercode = data["versionCode"];
				  $scope.iconame = data["appicon"];
				  $scope.$apply();
				},
				error: function (data, status, e)//服务器响应失败处理函数
				{
					$("#uploadTip").modal('hide');
					console.log(data);
				}
			}
		)
	}
	
  
	$scope.logout = function()
	{
		$scope.loginstate0 = 0;
		$scope.loginstate = 0;
		$scope.loginstate1 = 0;
		$scope.loginadminstate = 0;
		$scope.username = '';
		$scope.password = '';
		LoginData.state = 0;
		LoginData.name = '';
		LoginData.pwd = '';
		UserLogout(null, null);
		window.location = "login.php";
	}
  
  
  	$scope.setEnableIp = function(packagename)
    {

      var EnableIp = ($("#checkbox_ip").prop("checked")==true) ? 1 : 0;
      $.ajax( {
          url: "app/setenableip.php",
          data: {"setenableip":EnableIp},
          type: 'get',
          dataType: 'jsonp',
          jsonp: "jsoncallback",
          success: function(data, status){
              console.log(data);
              if (data.result == 0){     
				alert("修改成功");
                console.log("成功");
              }
              else if (data.result == 1){
				alert("修改失败");
				console.log("失败");
              }
			  
			  
			$http.get(roothttpaddress+'getenableip.php').success(function(data){
			console.log(data);  
			$scope.getenableip = data;
			if($scope.getenableip.enable == true)
				$scope.getenableip.enable = true;
			else
				$scope.getenableip.enable = false;
			});
			  
			  
			$http({
			url:roothttpaddress+'getapplist.php',  
			method: 'get',    
			params: { devicesetss: 'apps_setstatus.sets' }//作为消息体参数    
			}).success(function(data){
				$scope.applist={sets : "apps_setstatus.sets",device : "全部",setid:1};
				allApps = data;
				console.log(allApps);
				var abb ={};
				$scope.allapps = allApps;
				$scope.alldata = $scope.allapps;
				abb = $scope.alldata.concat($scope.applist);
				abb.reverse();
				$scope.alldata = abb;
				for(var i in $scope.alldata){
					if($scope.alldata[i].setid==1){//将id是1的设为选中项.
						$scope.appsDevice=$scope.alldata[i];
						break;
					}
				}
			}).error(function(data){
				console.log("error");  
			});
			 
			 
			$scope.$apply();
			  
			  
          },
          error: function(data, status){
              console.log(data);
          },
      });
    }
  
	$scope.clickupload = function()
	{
		var filenames = ["app_apk"];
		var app_forceinstall = $("input[name='app_forceinstall_radio']:checked").val();
		var app_icon = document.getElementById("app_icon").src;
		
		if($("#app_appname").val() == "" || $("#app_packagename").val() == "" || $("#app_version").val() == "" || $("#app_vercode").val() == "" || filenames == ""){
				alert("不能为空");
				return;
		}
	
    var params = {
		"app_category": $scope.curCategory.type, 
		"app_packagename": $("#app_packagename").val(), 
		"app_appname": $("#app_appname").val(), 
		"app_version": $("#app_version").val(), 
		"app_description": $("#app_description").val(), 
		"app_vercode": $("#app_vercode").val(), 
		"app_forceinstall": app_forceinstall, 
		"app_start": app_forceinstall, 
		"app_device": $("#app_device").val(), 
		"app_icon" : app_icon,
    };
	
    $("#uploadTip").modal('show');
    console.log(params);
    $.ajaxFileUpload
    (
        {
            url: 'app/uploadappfiles.php', //用于文件上传的服务器端请求地址
            secureuri: false, //一般设置为false
            fileElementId: filenames, //文件上传空间的id属性  <input type="file" id="file" name="file" />
            dataType: 'json', //返回值类型 一般设置为json
            data: params,
            success: function (data, status)  //服务器成功响应处理函数
            {
              console.log(data);
              $("#uploadTip").modal('hide');

              if (data["isexist"] == 1){
                alert("请勿重复上传");
              }
              else {
                $http.get(roothttpaddress+'/getapplist.php?devicesetss='+curDeviceType).success(function(data){
					allApps = data;
					console.log(allApps);
					$scope.allapps = allApps;
                 });
                $("#btn_uploadapp_close").click();
              }
                
            },
            error: function (data, status, e)//服务器响应失败处理函数
            {
                console.log(status);
                console.log(data);
            }
        }
    )
  };
  $scope.$watch( "selectedcategory", function(newValue, oldvalue) 
  {
 //   alert("selectedcategory change to "+$scope.selectedcategory);
  });
  
}]);
angular.module('AppStoreDemo.MainController')
.filter('to_trusted', ['$sce', function ($sce) {
    return function (text) {
        return $sce.trustAsHtml(text);
    };
}]);

angular.module('AppStoreDemo.MainController').filter('unique', function () {
	return function (collection, keyname) {
		var output = [],
	    keys = [];
		angular.forEach(collection, function (item) {
	    	var key = item[keyname];
	    	if (keys.indexOf(key) === -1) {
	    		keys.push(key);
	    		output.push(item);
	    	}
	  });
	  return output;
	};
});

angular.module('AppStoreDemo.ListController', ['ngRoute']).config(['$routeProvider', function($routeProvider) {
	$routeProvider.when('/applist/:category', {
		templateUrl: 'list.html',
		controller: 'AppListController'
	});
}])
.controller('AppListController', ['$scope','$routeParams','LoginData',function($scope,$routeParams,LoginData) {
	$scope.AppList = [];
	$scope.listinit = function()
	{
		$scope.loginstate = LoginData.state;
		$scope.category = $routeParams.category;
		if($scope.category==0)
		{
			$scope.AppList = allApps;
		}
		else
		{
			for(var i=0;i<allApps.length;i++)
				if(allApps[i].category==$scope.category)
					$scope.AppList.push(allApps[i]);
		}
		console.log($scope.AppList);
			$scope.pageIndex = 1;
			$scope.numOfPages = Math.ceil($scope.AppList.length/pagevolume);
	};
	$scope.undercarriage = function(packagename)
	{
    	if(window.confirm('您确定要下架软件吗？')){
    		console.log("undercarriage 1 packagename = " + packagename);
			$.ajax({
				url: "app/setoffshelf.php",
				data: {"packagename":packagename},
				type: 'get',
				dataType: 'jsonp',
				jsonp: "jsoncallback",
				success: function(data, status){
					console.log(data);
					if (data.result == 0){     
						console.log(data.packagename);
						var tmplist = [];
						for(var i=0;i<$scope.AppList.length;i++)
						{
						  if($scope.AppList[i].PackageName!=packagename)
							tmplist.push($scope.AppList[i]);
						}
							$scope.AppList = tmplist;
							var max;
							$scope.curAppList = [];
							($scope.pageIndex*pagevolume>$scope.AppList.length)?max=$scope.AppList.length:max=$scope.pageIndex*pagevolume;
							for(var i=($scope.pageIndex-1)*pagevolume;i<max;i++)
							$scope.curAppList.push($scope.AppList[i]);
							$scope.$apply();
					}
					else if (data.result == 1){
						//database error
						alert("下架操作失败。");
					}
				},
				error: function(data, status){
					console.log(data);
					alert("下架操作失败。");
				},
			});
            return true;
        }else{
            return false;
        }
    
    }
	$scope.setPage = function(index){
		$scope.pageIndex = index;
	};
	$scope.$watch( "pageIndex", function(newValue, oldvalue) 
	{
		var max;
		$scope.curAppList = [];
		($scope.pageIndex*pagevolume>$scope.AppList.length)?max=$scope.AppList.length:max=$scope.pageIndex*pagevolume;
		for(var i=($scope.pageIndex-1)*pagevolume;i<max;i++)
			$scope.curAppList.push($scope.AppList[i]);
	});
	
}]);

angular.module('AppStoreDemo.DetailController', ['ngRoute']).config(['$routeProvider', function($routeProvider) {
	$routeProvider.when('/view/:id', {
		templateUrl: 'detail.html',
		controller: 'AppDetailController'
	});
}])
.controller('AppDetailController', ['$scope','$routeParams','LoginData','$location',function($scope,$routeParams,LoginData,$location) {
    $scope.detailinit = function()
    {
      $scope.loginstate = LoginData.state;
        for(var i=0;i<allApps.length;i++)
            if(allApps[i].id==$routeParams.id)
            {
                $scope.item = allApps[i];
                break;
            }
			if($scope.item.ForceInstall=="true")
				$scope.item.forceInstall = true;
			else
				$scope.item.forceInstall = false;
    };
    $scope.undercarriage = function(packagename)
    {
    	if(window.confirm('您确定要下架软件吗？')){
			console.log("undercarriage 2 packagename = " + packagename);
			$.ajax( {
			url: "app/setoffshelf.php",
			data: {"packagename":packagename},
			type: 'get',
			dataType: 'jsonp',
			jsonp: "jsoncallback",
			success: function(data, status){
				console.log(data);
				if (data.result == 0)
				{     
					console.log(data.packagename);
					$location.path("/");
					$scope.$apply();
				}
				else if (data.result == 1){
						alert("下架操作失败。");
				}
			},
			error: function(data, status){
				console.log(data);
				alert("下架操作失败。");
			},
			});
            return true;
        }else{
            return false;
        }
    }
	
	$scope.fileUpChanged = function(ele){
		$("#uploadTip").modal('show');
		$.ajaxFileUpload
		(
			{
				url: 'app/apkupfiles.php', //用于文件上传的服务器端请求地址
				secureuri: false, //一般设置为false
				fileElementId: 'upgrade_apk', //文件上传空间的id属性  <input type="file" id="file" name="file" />
				dataType: 'json', //返回值类型 一般设置为json
				success: function (data, status)  //服务器成功响应处理函数
				{
					console.log(data);
					$scope.upgrade_version = data["versionName"];
					$scope.upgrade_vercode = data["versionCode"];
					$scope.$apply();
					$("#uploadTip").modal('hide');
				},
				error: function (data, status, e)//服务器响应失败处理函数
				{
					$("#uploadTip").modal('hide');
					console.log(data);
				}
			}
		)
	}
	
	
	
    $scope.upgradeapp = function()
    {
		var forceinstall = ($("#checkbox_forceinstall").prop("checked")==true) ? 1 : 0;
		var filenames = ["upgrade_apk"];  
		var params = {
        "app_packagename": $("#upgrade_packagename").text(), 
        "app_appname": $("#upgrade_appname").text(), 
        "app_version": $("#upgrade_version").val(), 
        "app_vercode": $("#upgrade_vercode").val(), 
		"app_start": "0",
        "app_icon": $("#app_icon").val(),	
        "app_forceinstall": forceinstall, 
				"app_description": $("#upgrade_description").val(),
        "upgradeapp": 1,		
      };
		var curver = {};
		curver.Ver = $("#upgrade_version").val();
		curver.Code = $("#upgrade_vercode").val();
		curver.Desc = $("#upgrade_description").val();
		curver.Time = new Date().Format("yyyyMMddhhmmss");
		var vername= $("#upgrade_version").val();
		var fileurl= $("#upgrade_apk").val();
		$("#uploadTip").modal('show');
		$.ajaxFileUpload
		(
			{
				url: 'app/uploadappfiles.php', //用于文件上传的服务器端请求地址
				secureuri: false, //一般设置为false
				fileElementId: filenames, //文件上传空间的id属性  <input type="file" id="file" name="file" />
				dataType: 'json', //返回值类型 一般设置为json
				data: params,
				success: function (data, status)  //服务器成功响应处理函数
				{
				console.log(JSON.stringify(data));
				$("#uploadTip").modal('hide');
					if (data["isexist"] == 1)
					{
						alert("请勿重复上传");
					}
					else
					{
						console.log(JSON.stringify(curver));
						$scope.item.Version.push(curver);
						sessionStorage.setItem("data", vername);
						$scope.item.Version[0].Ver= vername;
						$scope.item.Url1=data["Url1"];
						$scope.$apply();
						$("#btn_uploadapp_close").click();
					}
				},
				error: function (data, status, e)//服务器响应失败处理函数
				{
					console.log(status);
					console.log(JSON.stringify(data));
				}
			}
      )
    }
    $scope.setForceInstall = function(packagename)
    {
		//console.log($("#checkbox_forceinstall").prop("checked"));
		var forceinstall = ($("#checkbox_forceinstall").prop("checked")==true) ? 1 : 0;
		//console.log("setForceInstall  packagename = " + packagename + ", forceinstall = " + forceinstall);
		$.ajax( {
			url: "app/setforceinstall.php",
			data: {"packagename":packagename, "forceinstall":forceinstall},
			type: 'get',
			dataType: 'jsonp',
			jsonp: "jsoncallback",
			success: function(data, status){
				console.log(data);
				if (data.result == 0){     
					console.log(data.packagename);
					alert("修改成功");
				}
				else if (data.result == 1){              
					alert("修改失败。");
				}
			},
			error: function(data, status){
				console.log(data);
				alert("修改失败。");
			},
		});
    }
	
	
}]);

angular.module("AppStoreDemo.RootController", []).factory('LoginData', function() {
	return {
		name: "",
		pwd: "",
		state: 0
	}
}).controller("AppRootController",function ($scope) {

});

angular.module('AppStoreDemo', [
	'ngRoute',
	'AppStoreDemo.RootController',
	'AppStoreDemo.MainController',
	'AppStoreDemo.ListController',
	'AppStoreDemo.DetailController'
]).
config(['$routeProvider', function($routeProvider) {
	$routeProvider.otherwise({redirectTo: '/'});
}]);

angular.module("AppStoreDemo").filter("range", function () {
    return function (input, min, max) {
        min = parseInt(min);
        max = parseInt(max);

        for (var i = min; i <= max; i++) {
            input.push(i);
        }

        return input;
    }
});

angular.module("AppStoreDemo").directive("showtab", function () {
	return {
		link: function (scope, element, attrs) {
			element.click(function(e) {
				e.preventDefault();
				scope.setCategory(e.target.id);
				scope.$apply(); 
				$(element).tab('show');
			});
		}
	};
});

//login
angular.module('AppStroeLoginDemo.LoginController', ['ngRoute']).config(['$routeProvider', function($routeProvider) {
	$routeProvider.when('/', {
		templateUrl: 'login.html',
		controller: 'AppLoginController'
	});
}])
.controller('AppLoginController', ['$scope','$http','LoginData',function($scope,$http,LoginData) {
	$scope.login = function()
	{
	$.ajax( {
		url: "app/ajax_user_login.php",
		data: {"loginname":$scope.username, "loginpass":$scope.password},
		type: 'get',
		dataType: 'jsonp',
		jsonp: "jsoncallback",
		success: function(data, status){
			console.log(data);
			if (data.result == 0){
				g_sessionid = data.sessionid;
				$scope.loginstate = 1;
				$scope.$apply();
				LoginData.state = 1;
				LoginData.name = $scope.username;
				LoginData.pwd = $scope.password;
				window.location.href = 'index.php';
				window.document.body.innerHTML   =   'index.php';
			}
			else if (data.result == 1){
				//用户名错误
				alert("用户名错误");
			}
			else if (data.result == 2){
				//密码错误
				alert("密码错误");
			}
			else if (data.result == 3){
				g_sessionid = data.sessionid;
				$scope.loginstate1 = 0;
				$scope.loginadminstate = 1;
				$scope.$apply();
				LoginData.state = 1;
				LoginData.name = $scope.username;
				LoginData.pwd = $scope.password;
				window.location.href = 'index.php';
			}
		},
		error: function(data, status){
			console.log(data);
		},
	}); 
	}
  
}]);

angular.module("AppStroeLoginDemo.LoginRootController", []).factory('LoginData', function() {
	return {
		name: "",
		pwd: "",
		state: 0
	}
}).controller("AppLoginRootController",function ($scope) {

});

angular.module('AppStroeLoginDemo', [
	'ngRoute',
	'AppStroeLoginDemo.LoginRootController',
	'AppStroeLoginDemo.LoginController'
]).config(['$routeProvider', function($routeProvider) {
	$routeProvider.otherwise({redirectTo: '/'});
}]);