<?php
include("config/fg_config.php");
session_start();
$_SESSION['username']=$fg_cfg["session"]["username"];
if(isset($_SESSION['appmanage_user_userid']))
{
   echo json_encode($_SESSION); 
}
?>

