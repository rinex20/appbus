<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");
$conn = connectdb();
include("config/fg_config.php");
include("config/fg_checksession.php");
session_destroy();

$msg = "";
$login = C_POST('login');
if ($login == "login1"){

	$loginname = C_POST('loginname');
	$loginpass = C_POST('loginpass');
	$t_login = checkUserLogin($conn, $loginname, md5($loginpass));
	if ($t_login["result"] == 0){
		$curTime = curTime();
		updateUserLogin($conn, $t_login["id"], $curTime);
		updateUserSession($conn, $t_login["id"], $curTime);
		$_SESSION[$fg_cfg["session"]["groupid"]] = $t_login["group_id"];
		$_SESSION[$fg_cfg["session"]["userid"]] = $t_login["id"];
		$_SESSION[$fg_cfg["session"]["username"]] = $t_login["loginname"];
		$sessionid = session_id();
		$_SESSION[$fg_cfg["session"]["sessionid"]] = $sessionid;
		$fg_cfg["session"]["flag"] = 1;
	}else if ($t_login["result"] == 1){
		$msg = "用户名错误";
	}else{
		$msg = "密码错误";
	}
}

?> 
 <!DOCTYPE html>
<html ng-app="AppStroeLoginDemo" xmlns="http://www.w3.org/1999/xhtml" ng-controller="AppLoginRootController">
<head>
<title>appbus登录</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta HTTP-EQUIV="pragma" CONTENT="no-cache"> 
<meta HTTP-EQUIV="Cache-Control" CONTENT="no-cache, must-revalidate"> 
<meta HTTP-EQUIV="expires" CONTENT="0">
<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="public/css/buttons.css">
<link rel="stylesheet" type="text/css" href="public/css/main.css">
<link rel="stylesheet" type="text/css" href="public/css/normalize.css">
<script src="public/js/jquery-2.1.1.min.js"></script>
<script src="public/js/bootstrap.js"></script>
<script src="public/js/angular.js"></script>
<script src="public/js/angular-route.min.js"></script>
<script src="public/js/ui-bootstrap-0.11.0.min.js"></script>
<script src="public/js/ui-bootstrap-tpls-0.11.0.min.js"></script>
<script src="public/js/main.js"></script>
<script type="text/javascript" src="app.config"></script>
<script src="app.js" type="text/javascript"></script>
<script src="public/js/ajaxfileupload.js"></script>

</head>
<body><div ng-view class="login"></div></body>
</html>