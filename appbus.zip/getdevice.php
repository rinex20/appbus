<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();
/* mysql_query("SET NAMES 'utf8'");
mysql_query("SET CHARACTER_SET_CLIENT=utf8");
mysql_query("SET CHARACTER_SET_RESULTS=utf8");  */
$conn->query('SET NAMES utf8'); 
$conn->query("SET CHARACTER_SET_CLIENT=utf8");
$conn->query("SET CHARACTER_SET_RESULTS=utf8");

$jsoncallback = C_GET("jsoncallback");

header('Content-Type: text/html; charset=utf-8');

$g_packagenames = array();
$g_apps = array();
$sql = "select * from {$dbPrefix}setstatus";
//echo $sql;
//$result = mysql_query($sql, $conn);
$result = $conn->query($sql);
while($rows = $result->fetch()){
	$g_apps[] = $rows;
}
/* while ($rows = mysql_fetch_array($result))
{
  $g_apps[] = $rows;
} */
if ($g_apps){    
    	foreach ($g_apps as $i => $shot) {
    		$response[] = $shot["sets"];
    }
}

if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}


?>