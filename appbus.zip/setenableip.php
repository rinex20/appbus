<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();

include("config/fg_config.php");


session_start();

$jsoncallback = C_GET("jsoncallback");

header('Content-Type: text/html; charset=utf-8');

$enable = C_REQUEST('setenableip');
$sql = "update {$dbPrefix}enableip set enable = '$enable'";
$result = $conn->exec($sql);
$response["sql"] = $sql;

if ($result)
    $response["result"] = 0;
else
    $response["result"] = 1;


if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}
?>
