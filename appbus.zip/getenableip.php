<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();
$conn->query('SET NAMES utf8'); 
$conn->query("SET CHARACTER_SET_CLIENT=utf8");
$conn->query("SET CHARACTER_SET_RESULTS=utf8");
$jsoncallback = C_GET("jsoncallback");
$type = C_GET("type");
function getPackageNameIdx($packagename, $list){
    $idx = -1;
    foreach ($list as $i => $value) {
        if ($value == $packagename){
            $idx = $i;
            break;
        }
    }
    return $idx;
}
header('Content-Type: text/html; charset=utf-8');
$g_apps = array();
$sql = "select * from {$dbPrefix}enableip";
$result = $conn->query($sql);
while($rows = $result->fetch())
{
	$g_apps[] = $rows;
}
$response = array();
foreach ($g_apps as $key => $apps){
    //$_t["enable"] = $apps["enable"];
	if($apps["enable"] == "1"){
		$response["enable"]= true;
	}else{
		$response["enable"]= false;
	}
}
if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}


?>