<?php
include("config/config.php");
include("config/dbfunc.php");
include("config/functions.php");

$conn = connectdb();

include("config/fg_config.php");


session_start();

$jsoncallback = C_GET("jsoncallback");

header('Content-Type: text/html; charset=utf-8');

$inModel= C_REQUEST('inModel');
if(trim($inModel) != ""){
	$sql = "select * from {$dbPrefix}setstatus";
	$result = $conn->query($sql);
	while($rows = $result->fetch()){
		$g_apps[] = $rows;
	}
	foreach ($g_apps as $key => $cuts){
		if($cuts['sets']  == $inModel){
				$response["result"] = 1;//已有
		}
	}
	if($response["result"] != 1){
		
			$addsql = "insert into {$dbPrefix}setstatus(sets, status, starts) values ('$inModel','ignore','0')";
			//$addsql = "insert into apps_setstatus(sets,status) values('$inModel','ignore')";
			$result = $conn->query($addsql);
			if($result){
				$response["result"] = 0; //成功
			}
		}
}else{
	$response["result"] = 2;//为空
}




if ($jsoncallback == ""){
    echo json_encode($response);    
} else {
    echo $jsoncallback."(";
    echo json_encode($response);
    echo ")";   
}

?>
